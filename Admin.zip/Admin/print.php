<?php
ini_set('session.gc_maxlifetime', 2678400);
ob_start();
session_start();
require_once("include/config.php");
require_once("include/gettipeakun.php");
// cek user login dengan session yg benar
if (!isset($_SESSION['usernameam']) or !isset($_SESSION['csam'])) {
    header("Location: login");
    die();
} else {
    $usernameam = $_SESSION['usernameam'];
    $sessionam = $_SESSION['csam'];
    $ceksession = mysqli_query($konek, "select * from user where username='$usernameam'");
    $xceksession = mysqli_fetch_array($ceksession);
    $truesession = $xceksession['session'];
    if ($_SESSION['csam'] <> $truesession) {
        header("Location: login");
        die();
    } else {

        $xdata = mysqli_query($konek, "select * from user where Username='$usernameam'");
        $getdata = mysqli_fetch_array($xdata);
        $getnama = $getdata['Nama'];

        $getpage = $_GET['Id'];
        if ($getpage == 'kasmasuk') {
            $pageTitle = "Laporan Kas Masuk";
        } else if ($getpage == 'capaianharian2') {
            $pageTitle = "Report Capaian - " . date('d-m-Y') . ' - ' . $getkantor;
        } else if ($getpage == 'capaianharian') {
            $pageTitle = "Report Capaian - " . date('d-m-Y') . ' - ' . $getkantor;
        } else if ($getpage == 'daftardonatur') {
            $pageTitle = "Laporan Daftar Donaur";
        }
        include("include/header.php");
        include("func/detailcapaian.php");

?>

        <style>
            .setFundraiser {
                display: none;
            }
        </style>

        <body class="hold-transition">
            <div class="wrapper">

                <?php
                // include("include/menu.php");
                include("func/terbilang.php");
                ?>

                <!-- Content Wrapper. Contains page content -->
                <!-- <div class="content-wrapper" style="padding: 20px;"> -->

                <!-- Main content -->
                <div class="content">
                    <div class="container-fluid">
                        <div class="row">
                            <!-- <div class="col-lg-12"> -->
                            <!-- KAS MASUK -->
                            <?php
                            if ($getpage == 'kasmasuk') {
                                require_once("detail/kasmasuk.php");
                            }
                            ?>
                            <!-- CAPAIAN HARIAN -->
                            <?php
                            if ($getpage == 'capaianharian') {
                                require_once("detail/capaianharianprint.php");
                            }
                            ?>
                            <!-- CAPAIAN HARIAN Test-->
                            <?php
                            if ($getpage == 'capaianharian2') {
                                require_once("detail/capaianharianprint2.php");
                            }
                            ?>
                            <!-- DAFTAR DONATUR -->
                            <?php
                            if ($getpage == 'daftardonatur') {
                                require_once("detail/daftardonatur.php");
                            }
                            ?>
                            <!-- </div> -->
                            <!-- /.col-md-6 -->
                        </div>
                        <!-- /.row -->
                    </div>
                    <!-- /.container-fluid -->
                </div>
                <!-- /.content -->
                <!-- </div> -->
                <!-- /.content-wrapper -->

                <!-- Control Sidebar -->
                <aside class="control-sidebar control-sidebar-dark">
                    <!-- Control sidebar content goes here -->
                </aside>
                <!-- /.control-sidebar -->
            </div>
            <!-- ./wrapper -->


            <script type="text/javascript">
                window.print();
            </script>
    <?php
    }
}
include("include/footer.php");
    ?>
        </body>

        </html>