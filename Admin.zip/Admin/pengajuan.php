<?php
ini_set('session.gc_maxlifetime', 2678400);
ob_start();
session_start();
require_once("include/config.php");
require_once("include/gettipeakun.php");
// cek user login dengan session yg benar
if (!isset($_SESSION['usernameam']) or !isset($_SESSION['csam'])) {
    header("Location: login");
    die();
} else {
    $usernameam = $_SESSION['usernameam'];
    $sessionam = $_SESSION['csam'];
    $ceksession = mysqli_query($konek, "select * from user where username='$usernameam'");
    $xceksession = mysqli_fetch_array($ceksession);
    $truesession = $xceksession['session'];
    if ($_SESSION['csam'] <> $truesession) {
        header("Location: login");
        die();
    } else {
        // ini yang dipakai
        include("include/header.php");
        $xdata = mysqli_query($konek, "select * from user where Username='$usernameam'");
        $getdata = mysqli_fetch_array($xdata);
        $getnama = $getdata['Nama'];
        $fnadmin = explode(" ", $getnama);
        // pilihfpindah tambahfundraiser tambahmitra

        if (isset($_POST['submit'])) {
            $dnohp = $_POST['donasinohp'];
            $dnama = $_POST['donasinama'];
            $dnominal = $_POST['donasinominal'];
            $dbank = $_POST['donasibank'];
            $dfundraiser = $_POST['donasifundraiser'];
            $dprogram = $_POST['donasiprogram'];
            $dketerangan = $_POST['donasiketerangan'];
            // $dthisname = $_POST['thisname'];
            $dthisnamel = $_POST['thisnamelist'];
            $dkategori =  $_POST['donasikategori'];
            $ddate =  $_POST['datedonasi'];
            // $sekarang = date("Y-m-d");
            $ceksekarang = date("Y-m-d");

            if ($ddate != '') {
                $sekarang = $ddate;
            } else {
                $sekarang = date("Y-m-d");
            }


            $getlastidd = mysqli_query($konek, "select Id from user_donatur ORDER BY Id DESC LIMIT 1");
            $lastidd = $getlastidd->fetch_object()->Id + 1;

            $getnohp = mysqli_query($konek, "select * from user_donatur where  `CP` ='$dnohp'");
            $datanohp = mysqli_fetch_array($getnohp);
            $thisnohp = $datanohp['CP'];

            if (
                !$dnohp || !$dnominal || !$dbank || !$dfundraiser || !$dprogram
            ) {
                $pesan = "<span>Lengkapi data dengan benar</span>";
            } else {
                if ($dnohp == $thisnohp && $dnama == '') {
                    $getiddonatur = mysqli_query($konek, "select * from user_donatur where CP='$dnohp'");
                    $thisgetiddonatur = mysqli_fetch_array($getiddonatur);
                    $thisiddonatur = $thisgetiddonatur['Id'];

                    $getfundraiser = mysqli_query($konek, "select Id_Fundaiser from donatur where Id_Fundaiser='$dfundraiser' and Id_Donatur= '$thisiddonatur';");
                    $thisgetfundraiser = mysqli_fetch_array($getfundraiser);
                    $thisiisfundraiser = $thisgetfundraiser['Id_Fundaiser'];

                    if ($thisiisfundraiser == '') {
                        $insert = mysqli_query($konek, "INSERT INTO `kas_masuk` VALUES ('', '$thisiddonatur', '$sekarang', '$dthisnamel', '$dprogram', '$dfundraiser', '$dbank', '$dnominal','$dketerangan', '$getnama');");
                        $insert3 = mysqli_query($konek, "INSERT INTO `donatur` VALUES ('', '$thisiddonatur', '$dfundraiser');");
                    } else {
                        $insert = mysqli_query($konek, "INSERT INTO `kas_masuk` VALUES ('', '$thisiddonatur', '$sekarang', '$dthisnamel', '$dprogram', '$dfundraiser', '$dbank', '$dnominal','$dketerangan', '$getnama');");
                        // $insert3 = mysqli_query($konek, "INSERT INTO `donatur` VALUES ('', '$thisiddonatur', '$dfundraiser');");
                    }
                } else if ($dnohp == $thisnohp && $dnama != '') {
                    $getiddonatur = mysqli_query($konek, "select * from user_donatur where CP='$dnohp'");
                    $thisgetiddonatur = mysqli_fetch_array($getiddonatur);
                    $thisiddonatur = $thisgetiddonatur['Id'];

                    $getfundraiser = mysqli_query($konek, "select Id_Fundaiser from donatur where Id_Fundaiser='$dfundraiser' and Id_Donatur= '$thisiddonatur';");
                    $thisgetfundraiser = mysqli_fetch_array($getfundraiser);
                    $thisiisfundraiser = $thisgetfundraiser['Id_Fundaiser'];

                    if ($thisiisfundraiser == '') {
                        $insert = mysqli_query($konek, "INSERT INTO `kas_masuk` VALUES ('', '$thisiddonatur', '$sekarang', '$dnama', '$dprogram', '$dfundraiser', '$dbank', '$dnominal','$dketerangan', '$getnama');");
                        $insert3 = mysqli_query($konek, "INSERT INTO `donatur` VALUES ('', '$thisiddonatur', '$dfundraiser');");
                    } else {
                        $insert = mysqli_query($konek, "INSERT INTO `kas_masuk` VALUES ('', '$thisiddonatur', '$sekarang', '$dnama', '$dprogram', '$dfundraiser', '$dbank', '$dnominal','$dketerangan', '$getnama');");
                    }
                } else if ($dthisnamel != '' && $dnama != '') {
                    $insert = mysqli_query($konek, "INSERT INTO `kas_masuk` VALUES ('', '$lastidd', '$sekarang', '$dthisnamel', '$dprogram', '$dfundraiser', '$dbank', '$dnominal','$dketerangan', '$getnama');");
                    $insert2 = mysqli_query($konek, "INSERT INTO `user_donatur` VALUES ('$lastidd', '$dnama', '$dnohp', '$ceksekarang','$dkategori');");
                    $insert3 = mysqli_query($konek, "INSERT INTO `donatur` VALUES ('', '$lastidd', '$dfundraiser');");
                } else {
                    $insert = mysqli_query($konek, "INSERT INTO `kas_masuk` VALUES ('', '$lastidd', '$sekarang', '$dnama', '$dprogram', '$dfundraiser', '$dbank', '$dnominal','$dketerangan', '$getnama');");
                    $insert2 = mysqli_query($konek, "INSERT INTO `user_donatur` VALUES ('$lastidd', '$dnama', '$dnohp', '$ceksekarang','$dkategori');");
                    $insert3 = mysqli_query($konek, "INSERT INTO `donatur` VALUES ('', '$lastidd', '$dfundraiser');");
                }
            }
        }
?>


        <body class="hold-transition">
            <div class="wrapper">

                <?php
                include("include/menu.php");
                include("func/terbilang.php");
                ?>

                <!-- Content Wrapper. Contains page content -->
                <div class="content-wrapper">
                    <!-- Main content -->
                    <div class="content" style="padding: 20px;">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-lg-12">
                                    <?php
                                    if ($gettipeakun == 'superuser' ||  $gettipeakun == 'Manager' ||  $gettipeakun == 'Admin') {
                                        require_once("content/inputpengajuan16.php");
                                    } else header("location: view");
                                    ?>
                                    <!-- TAMBAH KANTOR -->
                                    <?php
                                    if ($gettipeakun == 'superuser' ||  $gettipeakun == 'Manager' ||  $gettipeakun == 'Admin') {
                                        // require_once("content/daftarpengajuan17.php");
                                    }
                                    ?>

                                </div>
                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.container-fluid -->
                    </div>
                    <!-- /.content -->
                </div>
                <!-- /.content-wrapper -->

                <!-- Control Sidebar -->
                <aside class="control-sidebar control-sidebar-dark">
                    <!-- Control sidebar content goes here -->
                </aside>
                <!-- /.control-sidebar -->
            </div>
            <!-- ./wrapper -->

            <script>
                $(function() {
                    $("#DataTable1").DataTable({
                        "responsive": true,
                        "lengthChange": false,
                        "autoWidth": false,
                        "buttons": ["copy", "csv", "excel", "pdf", "print"]
                    }).buttons().container().appendTo('#DataTable1_wrapper .col-md-6:eq(0)');
                    $('#example1').DataTable({
                        "paging": true,
                        "lengthChange": false,
                        "searching": false,
                        "ordering": true,
                        "info": true,
                        "autoWidth": false,
                        "responsive": true,
                    });

                });
            </script>

    <?php
    }
}
include("include/footer.php");
    ?>
        </body>

        </html>