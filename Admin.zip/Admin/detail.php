<?php
ini_set('session.gc_maxlifetime', 2678400);
ob_start();
session_start();
require_once("include/config.php");
require_once("include/gettipeakun.php");
// cek user login dengan session yg benar
if (!isset($_SESSION['usernameam']) or !isset($_SESSION['csam'])) {
    header("Location: login");
    die();
} else {
    $usernameam = $_SESSION['usernameam'];
    $sessionam = $_SESSION['csam'];
    $ceksession = mysqli_query($konek, "select * from user where username='$usernameam'");
    $xceksession = mysqli_fetch_array($ceksession);
    $truesession = $xceksession['session'];
    if ($_SESSION['csam'] <> $truesession) {
        header("Location: login");
        die();
    } else {

        $xdata = mysqli_query($konek, "select * from user where Username='$usernameam'");
        $getdata = mysqli_fetch_array($xdata);
        $getnama = $getdata['Nama'];
        include("include/header.php");
        include("func/detailcapaian.php");
        $getpage = $_GET['Id'];
?>

        <style>
            .setFundraiser {
                display: none;
            }
        </style>

        <body class="hold-transition">
            <div class="wrapper">

                <?php
                include("include/menu.php");
                include("func/terbilang.php");
                ?>

                <!-- Content Wrapper. Contains page content -->
                <div class="content-wrapper" style="padding: 20px;">

                    <!-- Main content -->
                    <div class="content">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-lg-12">
                                    <!-- KAS MASUK -->
                                    <?php
                                    if ($getpage == 'kasmasuk') {
                                        require_once("detail/kasmasuk.php");
                                    }
                                    ?>
                                    <!-- CAPAIAN HARIAN -->
                                    <?php
                                    if ($getpage == 'capaianharian') {
                                        require_once("detail/capaianharian.php");
                                    }
                                    ?>
                                    <!-- DAFTAR DONATUR -->
                                    <?php
                                    if ($getpage == 'daftardonatur') {
                                        require_once("detail/daftardonatur.php");
                                    }
                                    ?>
                                    <!-- DAFTAR DONATUR -->
                                    <?php
                                    if ($getpage == 'capaianharian2') {
                                        require_once("detail/capaianharian2.php");
                                    }
                                    ?>
                                </div>
                                <!-- /.col-md-6 -->
                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.container-fluid -->
                    </div>
                    <!-- /.content -->
                </div>
                <!-- /.content-wrapper -->

                <!-- Control Sidebar -->
                <aside class="control-sidebar control-sidebar-dark">
                    <!-- Control sidebar content goes here -->
                </aside>
                <!-- /.control-sidebar -->
            </div>
            <!-- ./wrapper -->

            <script>
                // function getdata_nama(type) {
                //     var cek = $("#donasinohp").val();
                //     $.ajax({
                //         url: 'func/cekname.php',
                //         data: 'donasinohp=' + cek,
                //         type: 'GET',
                //         dataType: 'html',
                //         success: function(msg) {
                //             $("#thisname").html(msg);
                //         }
                //     });

                // }
            </script>

    <?php
    }
}
include("include/footer.php");
    ?>
        </body>

        </html>