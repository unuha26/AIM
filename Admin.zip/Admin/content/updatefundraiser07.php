<div class="card card-primary collapsed-card">
    <div class="card-header">
        <h3 class="card-title">Update Fundraiser</h3>

        <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                <i class="fas fa-plus"></i>
            </button>
        </div>
    </div>
    <div class="card-body" style="display: none;">
        <form role="form" method="POST" action="input" autocomplete="off">
            <?php
            if (isset($_POST['updatefundraiser'])) {
                echo $pesan;
            }
            ?>
            <div class="form-group">
                <label for="pilihfpindah">SDM</label>
                <select id="pilihfpindah" name="pilihfpindah" class="form-control custom-select">
                    <option selected disabled>Pilih SDM</option>
                    <?php
                    $querysdm = mysqli_query($konek, "SELECT fundraiser.Nama FROM fundraiser
                                                    INNER JOIN kantor on kantor.Id_User = fundraiser.Id_User
                                                    WHERE Kantor IN ('$getkantor', 'Resign')
                                                    ORDER BY Nama ASC;");
                    while ($getsdm = mysqli_fetch_array($querysdm)) {
                        $i++;
                        echo "<option>" . $getsdm['Nama'] . "</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
                <label for="tambahfundraiser">Fundraiser / Mitra</label>
                <select id="tambahfundraiser" name="tambahfundraiser" class="form-control custom-select">
                    <option selected disabled>Pilih Jenis</option>
                    <option>Fundraiser</option>
                    <option>Mitra</option>
                    <option>Publik</option>
                </select>
            </div>

            <div class="form-group">
                <label for="tambahmitra">Mitra dari</label>
                <select id="tambahmitra" name="tambahmitra" class="form-control custom-select">
                    <option selected disabled>Pilih Fundraiser</option>
                    <?php
                    $queryfundraiser = mysqli_query($konek, "SELECT nama FROM fundraiser");
                    while ($getfundraiser = mysqli_fetch_array($queryfundraiser)) {
                        $i++;
                        echo "<option>" . $getfundraiser['nama'] . "</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
                <input type="submit" name="pindahfundraiser" value="Submit" class="btn btn-success float-right">
            </div>
        </form>
    </div>
    <!-- /.card-body -->
</div>