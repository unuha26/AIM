<div class="card">
    <div class="card-body row hidesearch">
        <div class="col-md-4">
            <h3 class="card-title block">Daftar Program</h3>
            <table class="table table-striped table-valign-middle table-sm ">
                <thead>
                    <tr>
                        <th>Kelompok Dana</th>
                        <th>Akad</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $getdata = mysqli_query($konek, "SELECT * FROM `akad`");
                    while ($data = mysqli_fetch_array($getdata)) {
                        echo '<tr><td>' . $data['Kelompok_Dana'] . '</td><td>' . $data['Akad'] . '</td></tr>';
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <div class="col-md-4">
            <h3 class="card-title block">Daftar Kantor</h3>
            <table class="table table-striped table-valign-middle table-sm ">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Alamat</th>
                        <th>No Hp</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $getdata = mysqli_query($konek, "SELECT * FROM `daftar_kantor`");
                    while ($data = mysqli_fetch_array($getdata)) {
                        echo '<tr><td>' . $data['Nama'] . '</td><td>' . $data['Alamat'] . '</td><td>' . $data['NoHp'] . '</td></tr>';
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <div class="col-md-4">
            <h3 class="card-title block">Metode Pembayaran</h3>
            <table class="table table-striped table-valign-middle table-sm ">
                <thead>
                    <tr>
                        <th>Metode</th>
                        <th>Penanggung Jawab</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $getdata = mysqli_query($konek, "SELECT * FROM `metode`");
                    while ($data = mysqli_fetch_array($getdata)) {
                        echo '<tr><td>' . $data['Metode_Pembayaran'] . '</td><td>' . $data['Penanggung_Jawab'] . '</td></tr>';
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>