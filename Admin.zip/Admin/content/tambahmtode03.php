<div class="card card-primary collapsed-card">
    <div class="card-header">
        <h3 class="card-title">Tambah Metode Pembayaran</h3>

        <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                <i class="fas fa-plus"></i>
            </button>
        </div>
    </div>
    <div class="card-body" style="display: none;">
        <form role="form" method="POST" action="input" autocomplete="off">
            <?php
            if (isset($_POST['tambahmetode'])) {
                echo $pesan;
            }
            ?>
            <div class="form-group">
                <label for="NamaMetodeTambah">Nama Metode</label>
                <input type="text" name="NamaMetodeTambah" id="NamaMetodeTambah" class="form-control">
            </div>

            <div class="form-group">
                <label for="PenanggungJawabTambah">Penanggung Jawab</label>
                <select id="PenanggungJawabTambah" name="PenanggungJawabTambah" class="form-control custom-select">
                    <option selected disabled>Pilih Penanggung Jawab</option>
                    <?php
                    $getu = mysqli_query($konek, "SELECT fundraiser.Nama, fundraiser.Id_User, kantor.Kantor FROM fundraiser
                                                    INNER JOIN kantor on kantor.Id_User = fundraiser.Id_User
                                                    WHERE Kantor IN ('$getkantor', 'Resign')
                                                    ORDER BY Nama ASC");
                    while ($rowu = mysqli_fetch_array($getu)) {
                        echo '<option >' . $rowu['Nama'] . '</option>';
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
                <input type="submit" name="tambahmetode" value="Submit" class="btn btn-success float-right">
            </div>
        </form>
    </div>

    <!-- /.card-body -->
</div>