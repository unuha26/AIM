<!-- INPUT DONASI -->
<div class="card card-primary">
    <div class="card-header">
        <h3 class="card-title">Edit Data Donatur</h3>
    </div>
    <form role="form" method="POST" action="edit" autocomplete="off">
        <div class="card-body">
            <div class=" form-group">
                <label for="namadonatur">Nama Donatur</label>
                <input type="text" name="namadonatur" id="namadonatur" class="form-control" value="<?php echo $getdataidd['Nama_Donatur']; ?>">
                <input type="text" name="iddonatur" id="iddonatur" class="form-control" value="<?php echo $getdataidd['Id']; ?>" style="display: none;">
            </div>
            <div class=" form-group">
                <label for="cp">CP</label>
                <input type="text" name="cp" id="cp" class="form-control" value="<?php echo $getdataidd['CP']; ?>">
            </div>
            <div class=" form-group">
                <label for="kategori">Kategori</label>
                <input list="thiskategori" id="kategori" name="kategori" class="form-control" value="<?php echo $getdataidd['Kategori']; ?>">
                <datalist id="thiskategori">
                    <?php
                    $getdk = mysqli_query($konek, "SELECT DISTINCT Kategori FROM user_donatur;");
                    while ($rowdk = mysqli_fetch_array($getdk)) {
                        echo '<option>' . $rowdk['Kategori'] . '</option>';
                    }
                    ?>
                </datalist>
            </div>
            <div class="form-group">
                <input type="submit" name="submitdonatur" value="Submit" class="btn btn-success float-right">
            </div>
        </div>
    </form>
    <!-- /.card-body -->
</div>