<div class="card">
    <div class="card-header border-0">
        <h3 class="card-title">Daftar Fundraiser</h3>
    </div>
    <div class="card-body table-responsive">
        <table class="table table-striped table-valign-middle table-sm DynamicVerticalScroll">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Nama</th>
                    <th>Nomor HP</th>
                    <th>Status</th>
                    <th>Tipe Akun</th>
                    <th>Kantor</th>
                    <th>Tanggal Daftar</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($gettipeakun == 'superuser' ||  $user == $specialaccess) {
                    $query = 'SELECT user.Id, user.Nama, user.NoHp, fundraiser.Status_Mitra as Status, fundraiser.Mitra as Mitra, user.Tipe_Akun, kantor.Kantor, user.Tanggal_Daftar FROM `user`
                    INNER JOIN fundraiser ON fundraiser.Id_User=user.Id
                    INNER JOIN kantor ON kantor.Id_User=user.Id
                    ORDER BY Id DESC LIMIT 100;';
                } else if ($gettipeakun == 'Manager' ||  $gettipeakun == 'Admin') {
                    $query = "SELECT user.Id, user.Nama, user.NoHp, fundraiser.Status_Mitra as Status, fundraiser.Mitra as Mitra, user.Tipe_Akun, kantor.Kantor, user.Tanggal_Daftar FROM `user`
                    INNER JOIN fundraiser ON fundraiser.Id_User=user.Id
                    INNER JOIN kantor ON kantor.Id_User=user.Id
                    WHERE kantor.Kantor = '$getkantor'
                    ORDER BY Id DESC LIMIT 100;";
                } else {
                    $query = "SELECT user.Id, user.Nama, user.NoHp, fundraiser.Status_Mitra as Status, fundraiser.Mitra as Mitra, user.Tipe_Akun, kantor.Kantor, user.Tanggal_Daftar FROM `user`
                    INNER JOIN fundraiser ON fundraiser.Id_User=user.Id
                    INNER JOIN kantor ON kantor.Id_User=user.Id
                    ORDER BY Id DESC LIMIT 100;";
                }
                $getdata = mysqli_query($konek, "$query");
                while ($data = mysqli_fetch_array($getdata)) {
                    echo '<tr><td>' . $data['Id'] . '</td><td>' . $data['Nama'] . '</td><td>' . $data['NoHp'] . '</td><td>' . $data['Status'] . ' ' . $data['Mitra'] . '</td><td>' . $data['Tipe_Akun'] . '</td><td>' . $data['Kantor'] . '</td><td>' . $data['Tanggal_Daftar'] . '</td></tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
</div>