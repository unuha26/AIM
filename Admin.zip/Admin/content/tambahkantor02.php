<div class="card card-primary collapsed-card">
    <div class="card-header">
        <h3 class="card-title">Tambah Kantor</h3>

        <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                <i class="fas fa-plus"></i>
            </button>
        </div>
    </div>
    <div class="card-body" style="display: none;">
        <form role="form" method="POST" action="input" autocomplete="off">
            <?php
            if (isset($_POST['tambahkantor'])) {
                echo $pesan;
            }
            ?>
            <div class="form-group">
                <label for="NamaKantorTambah">Nama Kantor</label>
                <input type="text" name="NamaKantorTambah" id="NamaKantorTambah" class="form-control">
            </div>

            <div class="form-group">
                <label for="AlamatKantorTambah">Alamat Kantor</label>
                <input type="text" name="AlamatKantorTambah" id="AlamatKantorTambah" class="form-control">
            </div>

            <div class="form-group">
                <label for="CpKantorTambah">No Hp</label>
                <input type="number" name="CpKantorTambah" id="CpKantorTambah" class="form-control">
            </div>

            <div class="form-group">
                <input type="submit" name="tambahkantor" value="Submit" class="btn btn-success float-right">
            </div>
        </form>
    </div>
    <!-- /.card-body -->
</div>