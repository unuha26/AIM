<!-- INPUT DONASI -->
<div class="card card-primary">
    <div class="card-header">
        <h3 class="card-title">Input Donasi</h3>

        <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                <i class="fas fa-minus"></i>
            </button>
        </div>
    </div>
    <div id="donasinamashide" class="row m-3">
        <input list="donasinamas" id="donasinanaslist" name="donasinamas" class="form-control" placeholder="Cari Data Donatur" onchange="getdata_idf(this.value).value;">
        <datalist id="donasinamas">
            <?php
            $getdk = mysqli_query($konek, "SELECT DISTINCT `Nama_Donatur` FROM `user_donatur` ORDER BY Nama_Donatur");
            while ($rowdk = mysqli_fetch_array($getdk)) {
                echo '<option  value="' . $rowdk['Nama_Donatur'] . '">' . $rowdk['Nama_Donatur'] . '</option>';
            }
            ?>
        </datalist>
        <select name="donasinohp2" id="donasinohp2" class="form-control custom-select col-10" onchange="changeNumber()">
            <option selected disabled>Cari data donatur terlebih dahulu</option>
        </select>
        <button class="btn btn-success col-2" onclick="copyname()">Copy</button>
        <span style="width : 100%;"> Id Selanjutnya : <b><?php
                                                            $getlastidd = mysqli_query($konek, "SELECT Id FROM `user_donatur` ORDER BY `user_donatur`.`Id` DESC LIMIT 1");
                                                            $lastidd = $getlastidd->fetch_object()->Id + 1;
                                                            echo $lastidd;
                                                            ?></b></span>
        <?php
        $xdatalast = mysqli_query($konek, "SELECT kas_masuk.AtasNama as Nama, user_donatur.CP FROM `kas_masuk` INNER JOIN user_donatur ON user_donatur.Id = kas_masuk.Id_Donatur WHERE kas_masuk.Input_by = '$getnama' ORDER BY kas_masuk.Id DESC LIMIT 1");
        $getdatalast = mysqli_fetch_array($xdatalast);
        $lastcp = $getdatalast['CP'];
        $lastn = $getdatalast['Nama'];
        ?>
        <span style="width : 100%;">Data Terakhir | Nama : <?php echo $lastn; ?> - CP : <?php echo $lastcp; ?></span>
    </div>
    <form role="form" method="POST" action="input" autocomplete="off">
        <div class="card-body">
            <?php
            if (isset($_POST['submitdonasi']) || isset($_POST['submitdonasi2'])) {
                echo $pesan;
            }

            ?>
            <div class="form-group">
                <label for="donasinohp">No HP Donatur</label>
                <input type="text" name="donasinohp" id="donasinohp" class="form-control" onkeyup="return forceClean(this);" onchange="getdata_nama(this.value).value;" placeholder="Input NoHp">
            </div>


            <div class=" form-group">
                <label for="thisnamelist">Nama Donatur</label>
                <input type="text" name="donasinama" id="donasinama" class="form-control" placeholder="Nama Donatur Baru">
                <input list="thisname" id="thisnamelist" name="thisnamelist" class="form-control" onchange="getdata_namaf(this.value).value;" placeholder="Atas Nama Baru / Lain">
                <datalist id="thisname">
                    <option value="">Tampil jika donatur sudah ada</option>
                </datalist>
            </div>

            <div class="form-group">
                <label for="donasikategori">Kategori</label>
                <input list="thiskategori" id="donasikategori" name="donasikategori" class="form-control" placeholder="Kategori Donatur">
                <datalist id="thiskategori">
                    <?php
                    $getdk = mysqli_query($konek, "SELECT DISTINCT Kategori FROM user_donatur;");
                    while ($rowdk = mysqli_fetch_array($getdk)) {
                        echo '<option>' . $rowdk['Kategori'] . '</option>';
                    }
                    ?>
                </datalist>
            </div>

            <div class="form-group">
                <label for="donasinominal">Nominal</label>
                <!-- <input type="number" name="donasinominal" id="donasinominal" class="form-control"> -->
                <input type="number" list="thisnominal" id="donasinominal" name="donasinominal" class="form-control" placeholder="Nominal Donasi">
                <datalist id="thisnominal">
                    <?php
                    $getdk = mysqli_query($konek, "SELECT `Nominal`, COUNT( `Nominal` ) AS total FROM kas_masuk GROUP BY `Nominal`ORDER BY total DESC LIMIT 5;");
                    while ($rowdk = mysqli_fetch_array($getdk)) {
                        echo '<option>' . $rowdk['Nominal'] . '</option>';
                    }
                    ?>
                </datalist>
            </div>
            <div class="form-group">
                <label for="donasibank">Metode</label>
                <input type="text" list="thisdonasibank" id="donasibank" name="donasibank" class="form-control" placeholder="Pilih Metode">
                <datalist id="thisdonasibank">
                    <?php
                    $getb = mysqli_query($konek, "SELECT * FROM metode ORDER BY `Metode_Pembayaran` ASC");
                    while ($rowb = mysqli_fetch_array($getb)) {
                        echo '<option value="' . $rowb['Id'] . '">' . $rowb['Metode_Pembayaran'] . '</option>';
                    }
                    ?>
                </datalist>
            </div>
            <div class="form-group" id="donasifundraisergrup">
                <label for="donasifundraiser">Fundraiser</label>
                <input list="donasifundraiserlist" id="donasifundraiser" name="donasifundraiser" class="form-control" placeholder="Pilih Fundraiser">
                <datalist id="donasifundraiserlist">
                    <?php
                    $getf = mysqli_query($konek, "SELECT fundraiser.Nama, fundraiser.Id_User, kantor.Kantor FROM fundraiser
                                                    INNER JOIN kantor on kantor.Id_User = fundraiser.Id_User
                                                    WHERE Kantor IN ('$getkantor', 'Resign')
                                                    ORDER BY Nama ASC");
                    while ($rowf = mysqli_fetch_array($getf)) {
                        echo '<option value="' . $rowf['Id_User'] . '">' . $rowf['Nama'] . '</option>';
                    }
                    ?>
                </datalist>
                </select>
            </div>
            <div class="form-group">
                <label for="donasiprogram">Program</label>
                <input type="text" list="thisdonasiprogram" id="donasiprogram" name="donasiprogram" class="form-control" placeholder="Pilih Program">
                <datalist id="thisdonasiprogram">
                    <?php
                    $geta = mysqli_query($konek, "SELECT * FROM akad");
                    while ($rowa = mysqli_fetch_array($geta)) {
                        echo '<option value="' . $rowa['Id'] . '">' . $rowa['Akad'] . '</option>';
                    }
                    ?>
                </datalist>
            </div>
            <div class="form-group">
                <label for="datedonasi">Tanggal</label>
                <input type="date" name="datedonasi" id="datedonasi" class="form-control">
            </div>
            <div class="form-group">
                <label for="donasiketerangan">Keterangan</label>
                <textarea name="donasiketerangan" id="donasiketerangan" class="form-control" placeholder="Nomor Transaksi / Keterangan Lainnya"></textarea>
            </div>

            <div class="form-group">
                <input type="submit" name="submitdonasi" value="Submit" class="btn btn-success float-right">
            </div>
            <div class="form-group">
                <input type="submit" name="submitdonasi2" value="Submit dan Download Kwitansi" class="btn btn-success float-right" style="margin-right: 15px;">
            </div>
        </div>
    </form>
    <!-- /.card-body -->
</div>
<script>
    function copyname() {
        var x = document.getElementById("donasinohp2");
        navigator.clipboard.writeText(x.value);
        // alert("Text Berhasil di Salin");
    }

    // function changeNumber() {
    //     var mylist = document.getElementById("donasinohp2").text;
    //     document.getElementById("donasinohp").value = mylist.options[mylist.selectedIndex].text;
    // }
</script>