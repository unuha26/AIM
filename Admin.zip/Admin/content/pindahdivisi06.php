<div class="card card-primary collapsed-card">
    <div class="card-header">
        <h3 class="card-title">Pindah Divisi / Kantor</h3>

        <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                <i class="fas fa-plus"></i>
            </button>
        </div>
    </div>
    <div class="card-body" style="display: none;">
        <form role="form" method="POST" action="input" autocomplete="off">
            <?php
            if (isset($_POST['pindahdivisi'])) {
                echo $pesan;
            }
            ?>
            <div class="form-group">
                <label for="pilihsdmpindah">SDM</label>
                <select id="pilihsdmpindah" name="pilihsdmpindah" class="form-control custom-select">
                    <option selected disabled>Pilih SDM</option>
                    <?php
                    $querysdm = mysqli_query($konek, "SELECT fundraiser.Nama FROM fundraiser
                                                    INNER JOIN kantor on kantor.Id_User = fundraiser.Id_User
                                                    WHERE Kantor IN ('$getkantor', 'Resign')
                                                    ORDER BY Nama ASC;");
                    while ($getsdm = mysqli_fetch_array($querysdm)) {
                        $i++;
                        echo "<option>" . $getsdm['Nama'] . "</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
                <label for="divisipindah">Divisi</label>

                <input list="divisipindahlist" id="divisipindah" name="divisipindah" class="form-control">
                <datalist id="divisipindahlist">
                    <?php
                    $querysdmt = mysqli_query($konek, "SELECT DISTINCT Tipe_Akun FROM user WHERE Tipe_Akun != 'superuser' AND Tipe_Akun != 'Resign'");
                    while ($getsdmt = mysqli_fetch_array($querysdmt)) {
                        $i++;
                        echo "<option>" . $getsdmt['Tipe_Akun'] . "</option>";
                    }
                    ?>
                    <option>Resign</option>
                </datalist>

            </div>
            <div class="form-group">
                <label for="pilihkantorpindah">Kantor</label>
                <select id="pilihkantorpindah" name="pilihkantorpindah" class="form-control custom-select">
                    <option selected disabled>Pilih Kantor</option>
                    <?php
                    $querysdmt = mysqli_query($konek, "SELECT DISTINCT Nama FROM `daftar_kantor` where Nama != 'Resign'");
                    while ($getsdmt = mysqli_fetch_array($querysdmt)) {
                        $i++;
                        echo "<option>" . $getsdmt['Nama'] . "</option>";
                    }
                    ?>
                    <option>Resign</option>
                </select>
            </div>
            <div class="form-group">
                <input type="submit" name="pindahdivisi" value="Submit" class="btn btn-success float-right">
            </div>
        </form>
    </div>
    <!-- /.card-body -->
</div>