<div class="card card-primary">
    <div class="card-header">
        <h3 class="card-title">Tambah User</h3>

        <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                <i class="fas fa-minus"></i>
            </button>
        </div>
    </div>
    <form role="form" method="POST" action="input" autocomplete="off">
        <div class="card-body">
            <?php
            if (isset($_POST['submit'])) {
                echo $pesan;
            }
            ?>
            <div class="form-group">
                <label for="tambahnama">Nama</label>
                <input type="text" id="tambahnama" name="tambahnama" class="form-control">
            </div>

            <div class="form-group">
                <label for="tambahusername">Username</label>
                <input type="text" id="tambahusername" name="tambahusername" class="form-control" onkeyup="return forceLower(this);">
            </div>

            <div class="form-group">
                <label for="tambahnohp">No HP</label>
                <input type="number" id="tambahnohp" name="tambahnohp" class="form-control">
            </div>

            <div class="form-group">
                <label for="tambahpassword">Password</label>
                <input type="password" id="tambahpassword" name="tambahpassword" class="form-control">
            </div>

            <div class="form-group">
                <label for="tambahtipeakun">Tipe Akun</label>
                <select id="tambahtipeakun" name="tambahtipeakun" class="form-control custom-select">
                    <option selected disabled>Pilih Tipe Akun</option>
                    <option>SDM</option>
                    <option>Admin</option>
                    <option>Manager</option>
                    <option>Mitra</option>
                </select>
            </div>

            <div class="form-group">
                <label for="tambahkantor">Kantor</label>
                <select id="tambahkantor" name="tambahkantor" class="form-control custom-select">
                    <option selected disabled>Pilih Kantor</option>
                    <?php
                    $getk = mysqli_query($konek, "SELECT * FROM daftar_kantor");
                    while ($rowk = mysqli_fetch_array($getk)) {
                        echo '<option>' . $rowk['Nama'] . '</option>';
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
                <label for="tambahfundraiser">Fundraiser / Mitra</label>
                <select id="tambahfundraiser" name="tambahfundraiser" class="form-control custom-select">
                    <option selected disabled>Pilih Jenis</option>
                    <option>Fundraiser</option>
                    <option>Mitra</option>
                </select>
            </div>

            <div class="form-group">
                <label for="tambahmitra">Mitra dari</label>
                <select id="tambahmitra" name="tambahmitra" class="form-control custom-select">
                    <option selected disabled>Pilih Fundraiser</option>
                    <?php
                    $queryfundraiser = mysqli_query($konek, "SELECT nama FROM fundraiser");
                    while ($getfundraiser = mysqli_fetch_array($queryfundraiser)) {
                        $i++;
                        echo "<option>" . $getfundraiser['nama'] . "</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
                <input type="submit" name="submit" value="Submit" class="btn btn-success float-right">
            </div>
        </div>
    </form>
</div>