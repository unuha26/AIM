<?php
$xdata = mysqli_query($konek, "select * from user where Username='$usernameam'");
$getdata = mysqli_fetch_array($xdata);
$nama = $getdata['Nama'];
?>
<div class="card">
    <div class="card-header border-0">
        <h3 class="card-title">Daftar Kas</h3>
        <br>
        <label for="">
            <?php
            echo 'Periode ' . $prevperiod . ' - Sampai ' . $nextperiod;
            ?>
        </label>
    </div>
    <div class="card-body table-responsive">
        <table id="" class="table table-striped table-valign-middle DynamicVerticalScroll">
            <thead>
                <tr>
                    <th>Kas</th>
                    <th>Harian (<?php echo $prevday; ?>)</th>
                    <th>Periode</th>
                    <th>Akumulasi</th>
                </tr>
            </thead>
            <tbody>
                <?php

                // $user = $_SESSION['usernameam'];
                if ($gettipeakun == 'superuser' ||  $user == $specialaccess || $gettipeakun == 'Manager' ||  $gettipeakun == 'Admin') {
                    $query = "SELECT metode.Id, metode.Metode_Pembayaran, (SELECT SUM(Nominal) FROM kas_masuk WHERE kas_masuk.Tanggal = '$prevday' AND kas_masuk.Id_Metode = metode.Id) AS CapaianHarian, (SELECT SUM(Nominal) FROM kas_masuk WHERE kas_masuk.Tanggal >= '$prevperiod' AND kas_masuk.Tanggal <= '$nextperiod' AND kas_masuk.Id_Metode = metode.Id) AS Periode, (SELECT SUM(Nominal) FROM kas_masuk WHERE kas_masuk.Id_Metode = metode.Id) AS Akumulasi
                                FROM kas_masuk
                                INNER JOIN metode ON metode.Id = kas_masuk.Id_Metode
                                GROUP BY metode.Metode_Pembayaran
                                ORDER BY metode.Metode_Pembayaran ASC LIMIT 100;";
                }
                $getdata = mysqli_query($konek, "$query");
                // $getdata = mysqli_query($konek, "SELECT fundraiser.Id, fundraiser.Status_Mitra as Status, fundraiser.Nama as NamaFundraiser, (SELECT SUM(Nominal) FROM kas_masuk WHERE Tanggal = '$prevday' AND kas_masuk.Id_Fundraiser = fundraiser.Id_User) AS CapaianHarian, (SELECT SUM(Nominal) FROM kas_masuk WHERE Tanggal >= '$prevperiod' AND Tanggal <= '$nextperiod' AND kas_masuk.Id_Fundraiser = fundraiser.Id_User) AS CapaianBulanan
                //                                     FROM kas_masuk
                //                                     INNER JOIN fundraiser ON fundraiser.Id_User=kas_masuk.Id_Fundraiser
                //                                     GROUP BY Id_Fundraiser ORDER BY Id_Fundraiser DESC LIMIT 100;");
                while ($data = mysqli_fetch_array($getdata)) {
                    echo '<tr><td>' . $data['Metode_Pembayaran'] . '</td><td>Rp ' . number_format($data['CapaianHarian'], 0, ',', '.') . '</td><td>Rp ' . number_format($data['Periode'], 0, ',', '.') . '</td><td>Rp ' . number_format($data['Akumulasi'], 0, ',', '.') . '</td></tr>';
                }
                ?>
            </tbody>
            <tfoot>
                <tr style="background-color: #007bff !important;font-weight: 500 !important;color: white;">
                    <td>Total</td>
                    <?php
                    if ($gettipeakun == 'superuser' ||  $user == $specialaccess || $gettipeakun == 'Manager' ||  $gettipeakun == 'Admin') {
                        $getdata = mysqli_query($konek, "SELECT SUM(Nominal) as Total FROM kas_masuk
                            WHERE Tanggal = '$prevday';");
                        while ($data = mysqli_fetch_array($getdata)) {
                            echo '<td>Rp ' . number_format($data['Total'], 0, ',', '.') . '</td>';
                        }
                    }
                    if ($gettipeakun == 'superuser' ||  $user == $specialaccess || $gettipeakun == 'Manager' ||  $gettipeakun == 'Admin') {
                        $getdata = mysqli_query($konek, "SELECT SUM(Nominal) as Periode FROM kas_masuk
                            WHERE Tanggal >= '$prevperiod' AND Tanggal <= '$nextperiod';");
                        while ($data = mysqli_fetch_array($getdata)) {
                            echo '<td>Rp ' . number_format($data['Periode'], 0, ',', '.') . '</td>';
                        }
                    }
                    if ($gettipeakun == 'superuser' ||  $user == $specialaccess || $gettipeakun == 'Manager' ||  $gettipeakun == 'Admin') {
                        $getdata = mysqli_query($konek, "SELECT SUM(Nominal) as Akumulasi FROM kas_masuk;");
                        while ($data = mysqli_fetch_array($getdata)) {
                            echo '<td>Rp ' . number_format($data['Akumulasi'], 0, ',', '.') . '</td>';
                        }
                    }
                    ?>
                </tr>
            </tfoot>
        </table>
    </div>
</div>