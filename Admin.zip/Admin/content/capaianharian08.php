<?php
$xdata = mysqli_query($konek, "select * from user where Username='$usernameam'");
$getdata = mysqli_fetch_array($xdata);
$nama = $getdata['Nama'];
?>

<div class="card">
    <div class="card-header border-0">
        <h3 class="card-title">Capaian Harian Funding</h3>
        <br>
        <label for="">
            <?php
            echo 'Periode ' . $prevperiod . ' - Sampai ' . $nextperiod;
            ?>
        </label>
        <?php
        if ($user == $specialaccess ||  $gettipeakun == 'superuser') {
            echo '<a href="print.php?Id=capaianharian2" target="_blank" class="btn btn-success float-right">Print Pusat</a>';
        }
        if ($user == $specialaccess ||  $gettipeakun == 'Admin' ||  $gettipeakun == 'Manager' ||  $gettipeakun == 'superuser') {
            echo '<a href="print.php?Id=capaianharian" target="_blank" class="btn btn-success float-right" style="margin-right: 15px;">Print Detail</a>';
        }
        ?>

    </div>
    <div class="card-body table-responsive">
        <table id="" class="table table-striped table-valign-middle DynamicVerticalScroll">
            <thead>
                <tr>
                    <th>Nama</th>
                    <th>Harian (<?php echo $prevday; ?>)</th>
                    <th>Akumulasi</th>
                </tr>
            </thead>
            <tbody>
                <?php

                // $user = $_SESSION['usernameam'];
                if ($gettipeakun == 'Mitra' ||  $gettipeakun == 'SDM' ||  $gettipeakun == 'Resign') {
                    $getdata = mysqli_query($konek, "SELECT fundraiser.Id, fundraiser.Status_Mitra as Status, fundraiser.Nama as NamaFundraiser, (SELECT SUM(Nominal) FROM kas_masuk WHERE Tanggal = '$prevday' AND kas_masuk.Id_Fundraiser = fundraiser.Id_User) AS CapaianHarian, (SELECT SUM(Nominal) FROM kas_masuk WHERE Tanggal >= '$prevperiod' AND Tanggal <= '$nextperiod' AND kas_masuk.Id_Fundraiser = fundraiser.Id_User) AS CapaianBulanan
                                                        FROM kas_masuk
                                                        INNER JOIN fundraiser ON fundraiser.Id_User=kas_masuk.Id_Fundraiser
                                                        WHERE fundraiser.Nama = '$nama'
                                                        GROUP BY Id_Fundraiser ORDER BY Id_Fundraiser DESC LIMIT 100;");
                    while ($data = mysqli_fetch_array($getdata)) {
                        echo '<tr><td><span class="set' . $data['Status'] . '">' . $data['Status'] . ' </span>' . $data['NamaFundraiser'] . '</td><td>Rp ' . number_format($data['CapaianHarian'], 0, ',', '.') . '</td><td>Rp ' . number_format($data['CapaianBulanan'], 0, ',', '.') . '</td></tr>';
                    }
                }
                if ($gettipeakun == 'superuser' ||  $user == $specialaccess) {
                    $query = " SELECT fundraiser.Id, fundraiser.Status_Mitra as Status, fundraiser.Nama as NamaFundraiser, (SELECT SUM(Nominal) FROM kas_masuk WHERE Tanggal = '$prevday' AND kas_masuk.Id_Fundraiser = fundraiser.Id_User) AS CapaianHarian, (SELECT SUM(Nominal) FROM kas_masuk WHERE Tanggal >= '$prevperiod' AND Tanggal <= '$nextperiod' AND kas_masuk.Id_Fundraiser = fundraiser.Id_User) AS CapaianBulanan
                                FROM kas_masuk
                                INNER JOIN fundraiser ON fundraiser.Id_User=kas_masuk.Id_Fundraiser
                                GROUP BY Id_Fundraiser ORDER BY Id_Fundraiser DESC LIMIT 100;";
                } else if ($gettipeakun == 'Manager' || $gettipeakun == 'Admin') {
                    $query = " SELECT fundraiser.Id, fundraiser.Status_Mitra as Status, fundraiser.Nama as NamaFundraiser, (SELECT SUM(Nominal) FROM kas_masuk WHERE Tanggal = '$prevday' AND kas_masuk.Id_Fundraiser = fundraiser.Id_User) AS CapaianHarian, (SELECT SUM(Nominal) FROM kas_masuk WHERE Tanggal >= '$prevperiod' AND Tanggal <= '$nextperiod' AND kas_masuk.Id_Fundraiser = fundraiser.Id_User) AS CapaianBulanan, kantor.Kantor
                                FROM kas_masuk
                                INNER JOIN fundraiser ON fundraiser.Id_User=kas_masuk.Id_Fundraiser
                                INNER JOIN kantor ON kantor.Id_User=kas_masuk.Id_Fundraiser
                                WHERE kantor.Kantor = '$getkantor'
                                GROUP BY Id_Fundraiser ORDER BY Id_Fundraiser DESC LIMIT 100;";
                } else {
                    $query = "   SELECT fundraiser.Id, fundraiser.Status_Mitra as Status, fundraiser.Nama as NamaFundraiser, (SELECT SUM(Nominal) FROM kas_masuk WHERE Tanggal = '$prevday' AND kas_masuk.Id_Fundraiser = fundraiser.Id_User) AS CapaianHarian, (SELECT SUM(Nominal) FROM kas_masuk WHERE Tanggal >= '$prevperiod' AND Tanggal <= '$nextperiod' AND kas_masuk.Id_Fundraiser = fundraiser.Id_User) AS CapaianBulanan
                                FROM kas_masuk
                                INNER JOIN fundraiser ON fundraiser.Id_User=kas_masuk.Id_Fundraiser
                                WHERE fundraiser.Mitra = '$nama'
                                GROUP BY Id_Fundraiser ORDER BY Id_Fundraiser DESC LIMIT 100;";
                }
                $getdata = mysqli_query($konek, "$query");
                // $getdata = mysqli_query($konek, "SELECT fundraiser.Id, fundraiser.Status_Mitra as Status, fundraiser.Nama as NamaFundraiser, (SELECT SUM(Nominal) FROM kas_masuk WHERE Tanggal = '$prevday' AND kas_masuk.Id_Fundraiser = fundraiser.Id_User) AS CapaianHarian, (SELECT SUM(Nominal) FROM kas_masuk WHERE Tanggal >= '$prevperiod' AND Tanggal <= '$nextperiod' AND kas_masuk.Id_Fundraiser = fundraiser.Id_User) AS CapaianBulanan
                //                                     FROM kas_masuk
                //                                     INNER JOIN fundraiser ON fundraiser.Id_User=kas_masuk.Id_Fundraiser
                //                                     GROUP BY Id_Fundraiser ORDER BY Id_Fundraiser DESC LIMIT 100;");
                while ($data = mysqli_fetch_array($getdata)) {
                    echo '<tr><td><span class="set' . $data['Status'] . '">' . $data['Status'] . ' </span>' . $data['NamaFundraiser'] . '</td><td>Rp ' . number_format($data['CapaianHarian'], 0, ',', '.') . '</td><td>Rp ' . number_format($data['CapaianBulanan'], 0, ',', '.') . '</td></tr>';
                }
                ?>
            </tbody>
            <tfoot>
                <tr style="background-color: #007bff !important;font-weight: 500 !important;color: white;">
                    <td>Total</td>
                    <?php
                    if ($gettipeakun == 'superuser' ||  $user == $specialaccess) {
                        $getdata = mysqli_query($konek, "SELECT SUM(Nominal) as Total FROM kas_masuk WHERE Tanggal = '$prevday';");
                        while ($data = mysqli_fetch_array($getdata)) {
                            echo '<td>Rp ' . number_format($data['Total'], 0, ',', '.') . '</td>';
                        }
                    } else if ($gettipeakun == 'Manager' ||  $gettipeakun == 'Admin') {
                        $getdata = mysqli_query($konek, "SELECT SUM(Nominal) as Total FROM kas_masuk 
                                INNER JOIN kantor ON kantor.Id_User=kas_masuk.Id_Fundraiser
                                WHERE Tanggal = '$prevday' AND kantor.Kantor = '$getkantor';");
                        while ($data = mysqli_fetch_array($getdata)) {
                            echo '<td>Rp ' . number_format($data['Total'], 0, ',', '.') . '</td>';
                        }
                    } else {
                        $xdata = mysqli_query($konek, "SELECT SUM(Nominal) as Total FROM kas_masuk
                        INNER JOIN fundraiser ON fundraiser.Id_User=kas_masuk.Id_Fundraiser
                        WHERE Tanggal = '$prevday' and fundraiser.Nama = '$nama';");
                        $getdata = mysqli_fetch_array($xdata);
                        $fundtotal = $getdata['Total'];

                        $xdatam = mysqli_query($konek, "SELECT SUM(Nominal) as Total FROM kas_masuk
                        INNER JOIN fundraiser ON fundraiser.Id_User=kas_masuk.Id_Fundraiser
                        WHERE Tanggal = '$prevday' and fundraiser.Mitra = '$nama';");
                        $getdatam = mysqli_fetch_array($xdatam);
                        $mitratotal = $getdatam['Total'];
                        $total = $fundtotal + $mitratotal;
                        echo '<td>Rp ' . number_format($total, 0, ',', '.') . '</td>';
                    }
                    ?>
                    <?php
                    if ($gettipeakun == 'superuser' ||  $user == $specialaccess) {
                        $getdata = mysqli_query($konek, "SELECT SUM(Nominal) as Akumulasi FROM kas_masuk WHERE Tanggal >= '$prevperiod' AND Tanggal <= '$nextperiod';");
                        while ($data = mysqli_fetch_array($getdata)) {
                            echo '<td>Rp ' . number_format($data['Akumulasi'], 0, ',', '.') . '</td>';
                        }
                    } else if ($gettipeakun == 'Admin' ||  $gettipeakun == 'Manager') {
                        $getdata = mysqli_query($konek, "SELECT SUM(Nominal) as Akumulasi FROM kas_masuk
                        INNER JOIN kantor ON kantor.Id_User=kas_masuk.Id_Fundraiser
                        WHERE Tanggal >= '$prevperiod' AND Tanggal <= '$nextperiod' AND kantor.Kantor = '$getkantor';");
                        while ($data = mysqli_fetch_array($getdata)) {
                            echo '<td>Rp ' . number_format($data['Akumulasi'], 0, ',', '.') . '</td>';
                        }
                    } else {
                        $xdata = mysqli_query($konek, "SELECT SUM(Nominal) as Akumulasi FROM kas_masuk
                        INNER JOIN fundraiser ON fundraiser.Id_User=kas_masuk.Id_Fundraiser
                        WHERE Tanggal >= '$prevperiod' AND Tanggal <= '$nextperiod' and fundraiser.Nama = '$nama';");
                        $getdata = mysqli_fetch_array($xdata);
                        $fundtotall = $getdata['Akumulasi'];

                        $xdatam = mysqli_query($konek, "SELECT SUM(Nominal) as Akumulasi FROM kas_masuk
                        INNER JOIN fundraiser ON fundraiser.Id_User=kas_masuk.Id_Fundraiser
                        WHERE Tanggal >= '$prevperiod' AND Tanggal <= '$nextperiod' and fundraiser.Mitra = '$nama';");
                        $getdatam = mysqli_fetch_array($xdatam);
                        $mitratotall = $getdatam['Akumulasi'];
                        $totall = $fundtotall + $mitratotall;
                        echo '<td>Rp ' . number_format($totall, 0, ',', '.') . '</td>';
                    }
                    ?>
                </tr>
            </tfoot>
        </table>
        <a href="detail.php?Id=capaianharian">Lihat Detail</a>
    </div>
</div>