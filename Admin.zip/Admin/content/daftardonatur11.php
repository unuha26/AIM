<div class="card">
    <div class="card-header border-0">
        <h3 class="card-title">Daftar Donatur</h3>
    </div>
    <div class="card-body table-responsive">
        <table class="table table-striped table-valign-middle table-sm DynamicVerticalScroll">
            <thead>
                <tr>
                    <th>Nama Donatur</th>
                    <th>Nomor HP</th>
                    <th>Kategori</th>
                    <th>Total Transaksi Donasi</th>
                    <th>Total Nominal Donasi</th>
                    <th>Tanggal Daftar</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // $user = $_SESSION['usernameam'];
                if ($gettipeakun == 'superuser' || $user == $specialaccess) {
                    $query = 'SELECT Id_Donatur as ID, user_donatur.Nama_Donatur, user_donatur.CP as NoHp, user_donatur.Kategori, COUNT(*) as Total, SUM(Nominal) AS Nominal, user_donatur.Tanggal_Daftar FROM kas_masuk
                                INNER JOIN user_donatur ON user_donatur.Id=kas_masuk.Id_Donatur
                                GROUP BY Id_Donatur ORDER BY Id_Donatur DESC LIMIT 100;';
                } else if ($gettipeakun == 'Manager' ||  $gettipeakun == 'Admin') {
                    $query = "SELECT Id_Donatur as ID, user_donatur.Nama_Donatur, user_donatur.CP as NoHp, user_donatur.Kategori, COUNT(*) as Total, SUM(Nominal) AS Nominal, user_donatur.Tanggal_Daftar FROM kas_masuk
                                INNER JOIN user_donatur ON user_donatur.Id=kas_masuk.Id_Donatur
                                INNER JOIN kantor ON kantor.Id_User=kas_masuk.Id_Fundraiser
                                WHERE kantor.Kantor = '$getkantor' GROUP BY Id_Donatur ORDER BY Id_Donatur DESC LIMIT 100;";
                } else {
                    $query = "SELECT Id_Donatur as ID, user_donatur.Nama_Donatur, user_donatur.CP as NoHp, user_donatur.Kategori, COUNT(*) as Total, SUM(Nominal) AS Nominal, user_donatur.Tanggal_Daftar, user.Username FROM kas_masuk
                                INNER JOIN user_donatur ON user_donatur.Id=kas_masuk.Id_Donatur
                                INNER JOIN user ON user.Id=kas_masuk.Id_Fundraiser
                                WHERE Username = '$user'
                                GROUP BY Id_Donatur 
                                ORDER BY Id_Donatur DESC LIMIT 100;";
                }
                $getdata = mysqli_query($konek, "$query");
                while ($data = mysqli_fetch_array($getdata)) {
                    echo '<tr><td>' . $data['Nama_Donatur'] . '</td><td>' . $data['NoHp'] . '</td><td>' . $data['Kategori'] . '</td><td>' . $data['Total'] . 'x</td><td>Rp ' . number_format($data['Nominal'], 0, ',', '.') . '</td><td>' . $data['Tanggal_Daftar'] . '</td></tr>';
                }
                ?>
            </tbody>
        </table>
        <a href="detail.php?Id=daftardonatur">Lihat Detail</a>
    </div>
</div>