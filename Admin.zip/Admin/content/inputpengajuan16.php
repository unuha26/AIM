<!-- INPUT DONASI -->
<div class="card card-primary">
    <div class="card-header">
        <h3 class="card-title">Input Pengajuan</h3>

        <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                <i class="fas fa-minus"></i>
            </button>
        </div>
    </div>
    <form role="form" method="POST" action="input" autocomplete="off">
        <div class="card-body">
            <?php
            if (isset($_POST['submit'])) {
                echo $pesan;
            }

            ?>
            <div class="form-group">
                <label for="nopengajuan">Nomor Pengajuan</label>
                <input type="text" name="nopengajuan" id="nopengajuan" class="form-control" placeholder="12/22/SDM/PUSAT">
            </div>

            <div class="form-group">
                <label for="datepengajuan">Tanggal</label>
                <input type="date" name="datepengajuan" id="datepengajuan" class="form-control">
            </div>

            <div class="form-group">
                <label for="kelompokdana">Kelompok Dana</label>
                <input list="kelompokdanalist" id="kelompokdana" name="kelompokdana" class="form-control" placeholder="Pilih Kelomok Dana">
                <datalist id="kelompokdanalist">
                    <?php
                    $getdk = mysqli_query($konek, "SELECT DISTINCT KelompokDana FROM pengajuan;");
                    while ($rowdk = mysqli_fetch_array($getdk)) {
                        echo '<option>' . $rowdk['KelompokDana'] . '</option>';
                    }
                    ?>
                </datalist>
            </div>

            <div class="form-group">
                <label for="alokasi">Alokasi</label>
                <input list="alokasilist" id="alokasi" name="alokasi" class="form-control" placeholder="Pilih Alokasi">
                <datalist id="alokasilist">
                    <?php
                    $getdk = mysqli_query($konek, "SELECT DISTINCT Alokasi FROM pengajuan;");
                    while ($rowdk = mysqli_fetch_array($getdk)) {
                        echo '<option>' . $rowdk['Alokasi'] . '</option>';
                    }
                    ?>
                </datalist>
            </div>

            <div class="form-group">
                <label for="datepelaksanaan">Tanggal Pelaksanaan</label>
                <input type="date" name="datepelaksanaan" id="datepelaksanaan" class="form-control">
            </div>

            <div class="form-group">
                <label for="program">Program</label>
                <input type="text" list="programlist" id="program" name="program" class="form-control" placeholder="Pilih Program">
                <datalist id="programlist">
                    <?php
                    $geta = mysqli_query($konek, "SELECT DISTINCT Program FROM pengajuan");
                    while ($rowa = mysqli_fetch_array($geta)) {
                        echo '<option value="' . $rowa['Id'] . '">' . $rowa['Program'] . '</option>';
                    }
                    ?>
                </datalist>
            </div>

            <div class="form-group">
                <label for="kategori">Nama Akun / Kategori</label>
                <input type="text" list="kategorilist" id="kategori" name="kategori" class="form-control" placeholder="Pilih Akun / Kategori">
                <datalist id="kategorilist">
                    <?php
                    $geta = mysqli_query($konek, "SELECT DISTINCT Akun FROM pengajuan");
                    while ($rowa = mysqli_fetch_array($geta)) {
                        echo '<option value="' . $rowa['Id'] . '">' . $rowa['Akun'] . '</option>';
                    }
                    ?>
                </datalist>
            </div>

            <div class="form-group">
                <label for="donasinominal">Rincian / Pengajuan</label>
                <!-- <input type="number" name="donasinominal" id="donasinominal" class="form-control"> -->
                <input type="number" list="kebutuhanlist" id="kebutuhan" name="kebutuhan" class="form-control" placeholder="Kebutuhan">
                <datalist id="kebutuhanlist">
                    <?php
                    $getdk = mysqli_query($konek, "SELECT DISTINCT Kebutuhan FROM pengajuan");
                    while ($rowdk = mysqli_fetch_array($getdk)) {
                        echo '<option>' . $rowdk['Kebutuhan'] . '</option>';
                    }
                    ?>
                </datalist>
                <input type="number" id="jumlah" name="jumlah" class="form-control" placeholder="Jumlah">
                <input type="number" list="satuanlist" id="satuan" name="donasinominal" class="form-control" placeholder="Satuan">
                <datalist id="satuanlist">
                    <?php
                    $getdk = mysqli_query($konek, "SELECT DISTINCT Satuan FROM pengajuan");
                    while ($rowdk = mysqli_fetch_array($getdk)) {
                        echo '<option>' . $rowdk['Satuan'] . '</option>';
                    }
                    ?>
                </datalist>
                <input type="number" id="nominal" name="nominal" class="form-control" placeholder="Harga/Nominal">
                <input type="number" id="total" name="total" class="form-control" placeholder="Total Pengajuan">
            </div>

            <div class="form-group">
                <label for="rekeningpencairan">Rekening Pencairan</label>
                <textarea name="rekeningpencairan" id="rekeningpencairan" class="form-control" placeholder="Bank - Nomor Rekening - Atas Nama"></textarea>
            </div>
            <div class="form-group">
                <label for="penanggungjawab">Penanggung Jawab</label>
                <input list="penanggungjawablist" id="penanggungjawab" name="penanggungjawab" class="form-control" placeholder="Penanggung Jawab">
                <datalist id="penanggungjawablist">
                    <?php
                    $getf = mysqli_query($konek, "SELECT fundraiser.Nama, fundraiser.Id_User, kantor.Kantor FROM fundraiser
                                                    INNER JOIN kantor on kantor.Id_User = fundraiser.Id_User
                                                    WHERE Kantor IN ('$getkantor', 'Resign')
                                                    ORDER BY Nama ASC");
                    while ($rowf = mysqli_fetch_array($getf)) {
                        echo '<option value="' . $rowf['Id_User'] . '">' . $rowf['Nama'] . '</option>';
                    }
                    ?>
                </datalist>
            </div>
            <div class="form-group">
                <input type="submit" name="submitpengajuan" value="Submit" class="btn btn-success float-right" disabled>
            </div>
        </div>
    </form>
    <!-- /.card-body -->
</div>
<script>
    function copyname() {
        var x = document.getElementById("donasinohp2");
        navigator.clipboard.writeText(x.value);
        // alert("Text Berhasil di Salin");
    }

    // function changeNumber() {
    //     var mylist = document.getElementById("donasinohp2").text;
    //     document.getElementById("donasinohp").value = mylist.options[mylist.selectedIndex].text;
    // }
</script>