<div class="card card-primary collapsed-card">
    <div class="card-header">
        <h3 class="card-title">Tambah Akad Program</h3>

        <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                <i class="fas fa-plus"></i>
            </button>
        </div>
    </div>
    <div class="card-body" style="display: none;">
        <form role="form" method="POST" action="input" autocomplete="off">
            <?php
            if (isset($_POST['tambahakad'])) {
                echo $pesan;
            }
            ?>
            <div class="form-group">
                <label for="NamaAkadTambah">Nama Akad</label>
                <input type="text" name="NamaAkadTambah" id="NamaAkadTambah" class="form-control">
            </div>

            <div class="form-group">
                <label for="KelompokDanaTambah">Kelompok Dana</label>
                <select id="KelompokDanaTambah" name="KelompokDanaTambah" class="form-control custom-select">
                    <option selected disabled>Pilih Kelompok Dana</option>
                    <?php
                    $getak = mysqli_query($konek, "SELECT DISTINCT `Kelompok_Dana`FROM akad");
                    while ($rowak = mysqli_fetch_array($getak)) {
                        echo '<option >' . $rowak['Kelompok_Dana'] . '</option>';
                    }
                    ?>
                </select>
                <input type="text" name="KelompokDanaBaruTambah" id="KelompokDanaBaruTambah" class="form-control" placeholder="Kelompok Dana Baru">
            </div>

            <div class="form-group">
                <input type="submit" name="tambahakad" value="Submit" class="btn btn-success float-right">
            </div>
        </form>
    </div>

    <!-- /.card-body -->
</div>