<div class="card">
    <div class="card-header border-0">
        <h3 class="card-title">Kas Masuk</h3>
    </div>
    <div class="card-body table-responsive">
        <table class="table table-striped table-valign-middle table-sm DynamicVerticalScroll">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Tanggal</th>
                    <th>Donatur</th>
                    <th>CP</th>
                    <th>Akad</th>
                    <th>Fundraiser</th>
                    <th>Metode</th>
                    <th>Nominal</th>
                    <th>Keterangan</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // $user = $_SESSION['usernameam'];
                if ($gettipeakun == 'superuser' ||  $user == $specialaccess) {
                    $query = '  SELECT kas_masuk.Id, kas_masuk.Tanggal, user_donatur.Nama_Donatur as AtasNama, user_donatur.CP as CP, akad.Akad, fundraiser.Nama as Fundraiser, metode.Metode_Pembayaran as Metode, kas_masuk.Nominal, kas_masuk.Keterangan FROM kas_masuk
                                    INNER JOIN user_donatur ON user_donatur.Id=kas_masuk.Id_Donatur
                                    INNER JOIN akad ON akad.Id=kas_masuk.Id_Akad
                                    INNER JOIN fundraiser ON fundraiser.Id_User=kas_masuk.Id_Fundraiser
                                    INNER JOIN metode ON metode.Id=kas_masuk.Id_Metode ORDER BY kas_masuk.Id DESC LIMIT 100;';
                } else if ($gettipeakun == 'Manager' ||  $gettipeakun == 'Admin') {
                    $query = "  SELECT kas_masuk.Id, kas_masuk.Tanggal, user_donatur.Nama_Donatur as AtasNama, user_donatur.CP as CP, akad.Akad, fundraiser.Nama as Fundraiser, metode.Metode_Pembayaran as Metode, kas_masuk.Nominal, kas_masuk.Keterangan FROM kas_masuk
                                    INNER JOIN user_donatur ON user_donatur.Id=kas_masuk.Id_Donatur
                                    INNER JOIN akad ON akad.Id=kas_masuk.Id_Akad
                                    INNER JOIN fundraiser ON fundraiser.Id_User=kas_masuk.Id_Fundraiser
                                    INNER JOIN metode ON metode.Id=kas_masuk.Id_Metode
                                    INNER JOIN kantor ON kantor.Id_User=kas_masuk.Id_Fundraiser
                                    WHERE kantor.Kantor = '$getkantor' ORDER BY kas_masuk.Id DESC LIMIT 100;";
                } else {
                    $query = "   SELECT kas_masuk.Id, kas_masuk.Tanggal, user_donatur.Nama_Donatur as AtasNama, user_donatur.CP as CP, akad.Akad, fundraiser.Nama as Fundraiser, metode.Metode_Pembayaran as Metode, kas_masuk.Nominal, kas_masuk.Keterangan, user.Username FROM kas_masuk
                                    INNER JOIN user_donatur ON user_donatur.Id=kas_masuk.Id_Donatur
                                    INNER JOIN akad ON akad.Id=kas_masuk.Id_Akad
                                    INNER JOIN fundraiser ON fundraiser.Id_User=kas_masuk.Id_Fundraiser
                                    INNER JOIN metode ON metode.Id=kas_masuk.Id_Metode
                                    INNER JOIN user ON user.Id=fundraiser.Id_User
                                    WHERE user.Username = '$user'
                                    ORDER BY kas_masuk.Id DESC LIMIT 100;";
                }
                $getdata = mysqli_query($konek, "$query");
                while ($data = mysqli_fetch_array($getdata)) {
                    if ($gettipeakun == 'superuser' ||  $gettipeakun == 'Manager' ||  $user == $specialaccess ||  $gettipeakun == 'Admin') {
                        echo '<tr><td><a href="edit?Id=' . $data["Id"] . '&Page=kasmasuk">' . $data["Id"] . '</a></td><td>' . $data['Tanggal'] . '</td><td>' . $data['AtasNama'] . '</td><td>' . $data['CP'] . '</td><td>' . $data['Akad'] . '</td><td>' . $data['Fundraiser'] . '</td><td>' . $data['Metode'] . '</td><td><a href="nota?Id=' . $data["Id"] . '" target="_blank">Rp ' . number_format($data['Nominal'], 0, ',', '.') . '</a></td><td>' . $data['Keterangan'] . '</td></tr>';
                    } else echo '<tr><td>' . $data['Id'] . '</td><td>' . $data['Tanggal'] . '</td><td>' . $data['AtasNama'] . '</td><td>' . $data['CP'] . '</td><td>' . $data['Akad'] . '</td><td>' . $data['Fundraiser'] . '</td><td>' . $data['Metode'] . '</td><td>Rp ' . number_format($data['Nominal'], 0, ',', '.') . '</td><td>' . $data['Keterangan'] . '</td></tr>';
                }
                ?>
            </tbody>
        </table>
        <a href="detail.php?Id=kasmasuk">Lihat Detail</a>
    </div>
</div>