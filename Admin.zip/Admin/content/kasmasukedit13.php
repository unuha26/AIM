<!-- INPUT DONASI -->
<div class="card card-primary">
    <div class="card-header">
        <h3 class="card-title">Input Donasi</h3>

        <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                <i class="fas fa-minus"></i>
            </button>
        </div>
    </div>
    <form role="form" method="POST" action="edit" autocomplete="off">
        <div class="card-body">
            <?php
            if (isset($_POST['submit'])) {
                echo $pesan;
            }

            ?>
            <div class="form-group">
                <label for="donasinohp">No HP Donatur</label>
                <input type="text" name="donasinohp" id="donasinohp" class="form-control" onkeyup="return forceClean(this);" onchange="getdata_nama(this.value).value;" value="<?php echo $getdataid['CP']; ?>" disabled>
                <input type="text" name="getid" id="getid" class="form-control" style="display: none;" value="<?php echo $getdataid['Id']; ?>">
                <input type="text" name="iddonatur" id="iddonatur" class="form-control" style="display: none;" value="<?php echo $getdataid['Id_Donatur']; ?>">
            </div>


            <div class=" form-group">
                <label for="thisnamelist">Nama Donatur</label>
                <input type="text" name="donasinama" id="donasinama" class="form-control" value="<?php echo $getdataid['AtasNama']; ?>" disabled>
                <input list="thisname" id="thisnamelist" name="thisnamelist" class="form-control" onchange="getdata_namaf(this.value).value;" placeholder="Atas Nama Baru / Lain" disabled>
                <datalist id="thisname">
                    <option value="">Tampil jika donatur sudah ada</option>
                </datalist>
            </div>

            <div class="form-group">
                <label for="donasikategori">Kategori</label>
                <input list="thiskategori" id="donasikategori" name="donasikategori" class="form-control" value="<?php echo $getdataid['Kategori']; ?>" disabled>
                <datalist id="thiskategori">
                    <?php
                    $getdk = mysqli_query($konek, "SELECT DISTINCT Kategori FROM user_donatur;");
                    while ($rowdk = mysqli_fetch_array($getdk)) {
                        echo '<option>' . $rowdk['Kategori'] . '</option>';
                    }
                    ?>
                </datalist>
            </div>

            <div class="form-group">
                <label for="donasinominal">Nominal</label>
                <!-- <input type="number" name="donasinominal" id="donasinominal" class="form-control"> -->
                <input type="number" list="thisnominal" id="donasinominal" name="donasinominal" class="form-control" value="<?php echo $getdataid['Nominal']; ?>">
                <datalist id="thisnominal">
                    <?php
                    $getdk = mysqli_query($konek, "SELECT `Nominal`, COUNT( `Nominal` ) AS total FROM kas_masuk GROUP BY `Nominal`ORDER BY total DESC LIMIT 5;");
                    while ($rowdk = mysqli_fetch_array($getdk)) {
                        echo '<option>' . $rowdk['Nominal'] . '</option>';
                    }
                    ?>
                </datalist>
            </div>
            <div class="form-group">
                <label for="donasibank">Metode</label>
                <input type="text" list="thisdonasibank" id="donasibank" name="donasibank" class="form-control" value="<?php echo $getdataid['Id_Metode']; ?>">
                <datalist id="thisdonasibank">
                    <?php
                    $getb = mysqli_query($konek, "SELECT * FROM metode ORDER BY `Metode_Pembayaran` ASC");
                    while ($rowb = mysqli_fetch_array($getb)) {
                        echo '<option value="' . $rowb['Id'] . '">' . $rowb['Metode_Pembayaran'] . '</option>';
                    }
                    ?>
                </datalist>
            </div>
            <div class="form-group" id="donasifundraisergrup">
                <label for="donasifundraiser">Fundraiser</label>
                <input list="donasifundraiserlist" id="donasifundraiser" name="donasifundraiser" class="form-control" value="<?php echo $getdataid['Id_Fundraiser']; ?>">
                <datalist id="donasifundraiserlist">
                    <?php
                    $getf = mysqli_query($konek, "SELECT * FROM fundraiser ORDER BY Nama ASC");
                    while ($rowf = mysqli_fetch_array($getf)) {
                        echo '<option value="' . $rowf['Id_User'] . '">' . $rowf['Nama'] . '</option>';
                    }
                    ?>
                </datalist>
                </select>
            </div>
            <div class="form-group">
                <label for="donasiprogram">Program</label>
                <input type="text" list="thisdonasiprogram" id="donasiprogram" name="donasiprogram" class="form-control" value="<?php echo $getdataid['Id_Akad']; ?>">
                <datalist id="thisdonasiprogram">
                    <?php
                    $geta = mysqli_query($konek, "SELECT * FROM akad");
                    while ($rowa = mysqli_fetch_array($geta)) {
                        echo '<option value="' . $rowa['Id'] . '">' . $rowa['Akad'] . '</option>';
                    }
                    ?>
                </datalist>
            </div>
            <div class="form-group">
                <label for="datedonasi">Tanggal</label>
                <input type="date" name="datedonasi" id="datedonasi" class="form-control" value="<?php echo $getdataid['Tanggal']; ?>">
            </div>
            <div class="form-group">
                <label for="donasiketerangan">Keterangan</label>
                <textarea name="donasiketerangan" id="donasiketerangan" class="form-control"><?php echo $getdataid['Keterangan']; ?></textarea>
            </div>

            <div class="form-group">
                <input type="submit" name="submit" value="Submit" class="btn btn-success float-right">
                <input type="submit" name="submit2" value="Hapus" class="btn btn-success float-right" style="margin: 0 10px;">
            </div>
        </div>
    </form>
    <!-- /.card-body -->
</div>
<script>
    function copyname() {
        var x = document.getElementById("donasinohp2");
        navigator.clipboard.writeText(x.value);
        // alert("Text Berhasil di Salin");
    }
</script>