<?php

$xdata = mysqli_query($konek, "select * from user where Username='$usernameam'");
$getdata = mysqli_fetch_array($xdata);
$nama = $getdata['Nama'];
?>
<div class="card">
    <div class="card-header border-0">
        <h3 class="card-title" style="text-align: center;display: block;width: 100%;font-size: 24px;font-weight: 600;">Report Capaian</h3>
        <label for="" style="font-weight: 400;text-align: center;display: block;font-size: .85em;">
            <?php
            echo 'Tanggal Report ' . date('d-m-Y');
            echo '<br>Periode ' . $prevperiod . ' - ' . $nextperiod;
            echo '<br>Bulan Lalu ' . $prevperiodlalu . ' - ' . $nextperiodlalu;
            ?>
        </label>
    </div>
    <div class="card-body table-responsive" style="border: 1px solid #9E9E9E;">
        <table id="" class="table table-striped table-valign-middle">
            <tbody>
                <!-- <thead> -->
                <tr>
                    <td>Nama</td>
                    <td style="border-left: 1px solid gray;">Harian (TF & Cash)</td>
                    <td>Harian (Non Cash)</td>
                    <td style="border-left: 1px solid gray;">Periode (TF)</td>
                    <td>Periode (Cash)</td>
                    <td>Periode (Non Cash)</td>
                    <td style="border-left: 1px solid gray;">Periode (Total)</td>
                    <td style="border-left: 1px solid gray;">Bulan Lalu</td>
                    <td style="border-left: 1px solid gray;">Akumulasi Tahunan</td>
                </tr>
                <!-- </thead> -->
                <?php

                if ($gettipeakun == 'superuser' || $gettipeakun == 'Manager' || $gettipeakun == 'Admin' ||  $user == $specialaccess) {

                    $rs = mysqli_query($konek, "SELECT DISTINCT Kantor FROM kantor WHERE kantor.Kantor = '$getkantor'");
                    while ($rowk = mysqli_fetch_assoc($rs)) {
                        $rs1 = mysqli_query($konek, "SELECT fundraiser.Id_User, fundraiser.Status_Mitra as Status, fundraiser.Nama as NamaFundraiser, fundraiser.Mitra as MitraDari, kantor.Kantor,
(SELECT SUM(IF(kas_masuk.Id_Metode IN (SELECT Id FROM metode WHERE metode.Metode_Pembayaran LIKE 'Non Cash'), kas_masuk.Nominal, 0)) FROM kas_masuk WHERE Tanggal = '$prevday' AND kas_masuk.Id_Fundraiser = fundraiser.Id_User) AS CapaianHarianNonCash,
(SELECT SUM(IF(kas_masuk.Id_Metode IN (SELECT Id FROM metode WHERE metode.Metode_Pembayaran NOT LIKE 'Non Cash'), kas_masuk.Nominal, 0)) FROM kas_masuk WHERE Tanggal = '$prevday' AND kas_masuk.Id_Fundraiser = fundraiser.Id_User) AS CapaianHarian,
(SELECT SUM(IF(kas_masuk.Id_Metode IN (SELECT Id FROM metode WHERE metode.Metode_Pembayaran NOT LIKE '%Cash%'), kas_masuk.Nominal, 0)) FROM kas_masuk WHERE Tanggal >= '$prevperiod' AND Tanggal <= '$nextperiod' AND kas_masuk.Id_Fundraiser = fundraiser.Id_User) AS CapaianBulananTF,
(SELECT SUM(IF(kas_masuk.Id_Metode IN (SELECT Id FROM metode WHERE metode.Metode_Pembayaran LIKE 'Cash%'), kas_masuk.Nominal, 0)) FROM kas_masuk WHERE Tanggal >= '$prevperiod' AND Tanggal <= '$nextperiod' AND kas_masuk.Id_Fundraiser = fundraiser.Id_User) AS CapaianBulananCash,
(SELECT SUM(IF(kas_masuk.Id_Metode IN (SELECT Id FROM metode WHERE metode.Metode_Pembayaran LIKE 'Non Cash'), kas_masuk.Nominal, 0)) FROM kas_masuk WHERE Tanggal >= '$prevperiod' AND Tanggal <= '$nextperiod' AND kas_masuk.Id_Fundraiser = fundraiser.Id_User) AS CapaianBulananNonCash,
(SELECT SUM(IF(kas_masuk.Id_Metode IN (SELECT Id FROM metode), kas_masuk.Nominal, 0)) FROM kas_masuk WHERE Tanggal >= '$prevperiod' AND Tanggal <= '$nextperiod' AND kas_masuk.Id_Fundraiser = fundraiser.Id_User) AS CapaianBulananTotal,
(SELECT SUM(IF(kas_masuk.Id_Metode IN (SELECT Id FROM metode), kas_masuk.Nominal, 0)) FROM kas_masuk WHERE Tanggal >= '$prevperiodlalu' AND Tanggal <= '$nextperiodlalu' AND kas_masuk.Id_Fundraiser = fundraiser.Id_User) AS CapaianBulanLalu,
(SELECT SUM(IF(kas_masuk.Id_Metode IN (SELECT Id FROM metode), kas_masuk.Nominal, 0)) FROM kas_masuk WHERE Tanggal >= '2021-12-26' AND Tanggal <= '2022-12-20' AND kas_masuk.Id_Fundraiser = fundraiser.Id_User) AS AkumulasiTahun
FROM kas_masuk
INNER JOIN kantor ON kantor.Id_User=kas_masuk.Id_Fundraiser
INNER JOIN fundraiser ON fundraiser.Id_User=kas_masuk.Id_Fundraiser
INNER JOIN metode ON metode.Id=kas_masuk.Id_Metode
WHERE Kantor = '{$rowk['Kantor']}' AND fundraiser.Status_Mitra != 'Mitra'
GROUP BY Id_Fundraiser ORDER BY Id_Fundraiser DESC");
                        if ($rowk['Kantor'] == 'Resign') {
                            $rowk['Kantor'] = 'Publik';
                        }
                        // echo "<b>" . $rowk['Kantor'] . "</b>";
                        echo '<tr style="font-weight: 600;"><td>Kantor : </td><td colspan="8">' . $rowk['Kantor'] . '</td></tr>';
                        while ($rowk1 = mysqli_fetch_assoc($rs1)) {
                            $rs2 = mysqli_query($konek, "SELECT fundraiser.Id_User, fundraiser.Status_Mitra as Status, fundraiser.Nama as NamaFundraiser, fundraiser.Mitra as MitraDari, kantor.Kantor,
(SELECT SUM(IF(kas_masuk.Id_Metode IN (SELECT Id FROM metode WHERE metode.Metode_Pembayaran LIKE 'Non Cash'), kas_masuk.Nominal, 0)) FROM kas_masuk WHERE Tanggal = '$prevday' AND kas_masuk.Id_Fundraiser = fundraiser.Id_User) AS CapaianHarianNonCash,
(SELECT SUM(IF(kas_masuk.Id_Metode IN (SELECT Id FROM metode WHERE metode.Metode_Pembayaran NOT LIKE 'Non Cash'), kas_masuk.Nominal, 0)) FROM kas_masuk WHERE Tanggal = '$prevday' AND kas_masuk.Id_Fundraiser = fundraiser.Id_User) AS CapaianHarian,
(SELECT SUM(IF(kas_masuk.Id_Metode IN (SELECT Id FROM metode WHERE metode.Metode_Pembayaran NOT LIKE '%Cash%'), kas_masuk.Nominal, 0)) FROM kas_masuk WHERE Tanggal >= '$prevperiod' AND Tanggal <= '$nextperiod' AND kas_masuk.Id_Fundraiser = fundraiser.Id_User) AS CapaianBulananTF,
(SELECT SUM(IF(kas_masuk.Id_Metode IN (SELECT Id FROM metode WHERE metode.Metode_Pembayaran LIKE 'Cash%'), kas_masuk.Nominal, 0)) FROM kas_masuk WHERE Tanggal >= '$prevperiod' AND Tanggal <= '$nextperiod' AND kas_masuk.Id_Fundraiser = fundraiser.Id_User) AS CapaianBulananCash,
(SELECT SUM(IF(kas_masuk.Id_Metode IN (SELECT Id FROM metode WHERE metode.Metode_Pembayaran LIKE 'Non Cash'), kas_masuk.Nominal, 0)) FROM kas_masuk WHERE Tanggal >= '$prevperiod' AND Tanggal <= '$nextperiod' AND kas_masuk.Id_Fundraiser = fundraiser.Id_User) AS CapaianBulananNonCash,
(SELECT SUM(IF(kas_masuk.Id_Metode IN (SELECT Id FROM metode), kas_masuk.Nominal, 0)) FROM kas_masuk WHERE Tanggal >= '$prevperiod' AND Tanggal <= '$nextperiod' AND kas_masuk.Id_Fundraiser = fundraiser.Id_User) AS CapaianBulananTotal,
(SELECT SUM(IF(kas_masuk.Id_Metode IN (SELECT Id FROM metode), kas_masuk.Nominal, 0)) FROM kas_masuk WHERE Tanggal >= '$prevperiodlalu' AND Tanggal <= '$nextperiodlalu' AND kas_masuk.Id_Fundraiser = fundraiser.Id_User) AS CapaianBulanLalu,
(SELECT SUM(IF(kas_masuk.Id_Metode IN (SELECT Id FROM metode), kas_masuk.Nominal, 0)) FROM kas_masuk WHERE Tanggal >= '2021-12-26' AND Tanggal <= '2022-12-20' AND kas_masuk.Id_Fundraiser = fundraiser.Id_User) AS AkumulasiTahun
FROM kas_masuk
INNER JOIN kantor ON kantor.Id_User=kas_masuk.Id_Fundraiser
INNER JOIN fundraiser ON fundraiser.Id_User=kas_masuk.Id_Fundraiser
INNER JOIN metode ON metode.Id=kas_masuk.Id_Metode
WHERE fundraiser.Mitra = '{$rowk1['NamaFundraiser']}' AND fundraiser.Status_Mitra = 'Mitra'
GROUP BY Id_Fundraiser ORDER BY Id_Fundraiser DESC");
                            // echo $rowk1['NamaFundraiser'];
                            echo '<tr><td><span class="set' . $rowk1['Status'] . '"></span>' . $rowk1['NamaFundraiser'] . '</td><td style="border-left: 1px solid gray;" class="Set' . number_format($rowk1['CapaianHarian'], 0, ',', '.') . '">' . number_format($rowk1['CapaianHarian'], 0, ',', '.') . '</td><td class="Set' . number_format($rowk1['CapaianHarianNonCash'], 0, ',', '.') . '">' . number_format($rowk1['CapaianHarianNonCash'], 0, ',', '.') . '</td><td style="border-left: 1px solid gray;" class="Set' . number_format($rowk1['CapaianBulananTF'], 0, ',', '.') . '">' . number_format($rowk1['CapaianBulananTF'], 0, ',', '.') . '</td><td class="Set' . number_format($rowk1['CapaianBulananCash'], 0, ',', '.') . '">' . number_format($rowk1['CapaianBulananCash'], 0, ',', '.') . '</td><td class="Set' . number_format($rowk1['CapaianBulananNonCash'], 0, ',', '.') . '">' . number_format($rowk1['CapaianBulananNonCash'], 0, ',', '.') . '</td><td class="Set' . number_format($rowk1['CapaianBulananTotal'], 0, ',', '.') . '" style="border-left: 1px solid gray;">' . number_format($rowk1['CapaianBulananTotal'], 0, ',', '.') . '</td><td class="Set' . number_format($rowk1['CapaianBulanLalu'], 0, ',', '.') . '" style="border-left: 1px solid gray;">' . number_format($rowk1['CapaianBulanLalu'], 0, ',', '.') . '</td><td class="Set' . number_format($rowk1['AkumulasiTahun'], 0, ',', '.') . '" style="border-left: 1px solid gray;">' . number_format($rowk1['AkumulasiTahun'], 0, ',', '.') . '</td></tr>';
                            while ($rowk2 = mysqli_fetch_assoc($rs2)) {
                                // echo "Mitra " . $rowk2['NamaFundraiser'];
                                echo '<tr><td><span class="set' . $rowk2['Status'] . '"></span>' . $rowk2['NamaFundraiser'] . '</td><td style="border-left: 1px solid gray;" class="Set' . number_format($rowk2['CapaianHarian'], 0, ',', '.') . '">' . number_format($rowk2['CapaianHarian'], 0, ',', '.') . '</td><td class="Set' . number_format($rowk2['CapaianHarianNonCash'], 0, ',', '.') . '">' . number_format($rowk2['CapaianHarianNonCash'], 0, ',', '.') . '</td><td style="border-left: 1px solid gray;" class="Set' . number_format($rowk2['CapaianBulananTF'], 0, ',', '.') . '">' . number_format($rowk2['CapaianBulananTF'], 0, ',', '.') . '</td><td class="Set' . number_format($rowk2['CapaianBulananCash'], 0, ',', '.') . '">' . number_format($rowk2['CapaianBulananCash'], 0, ',', '.') . '</td><td class="Set' . number_format($rowk2['CapaianBulananNonCash'], 0, ',', '.') . '">' . number_format($rowk2['CapaianBulananNonCash'], 0, ',', '.') . '</td><td class="Set' . number_format($rowk2['CapaianBulananTotal'], 0, ',', '.') . '" style="border-left: 1px solid gray;">' . number_format($rowk2['CapaianBulananTotal'], 0, ',', '.') . '</td><td class="Set' . number_format($rowk2['CapaianBulanLalu'], 0, ',', '.') . '" style="border-left: 1px solid gray;">' . number_format($rowk2['CapaianBulanLalu'], 0, ',', '.') . '</td><td class="Set' . number_format($rowk2['AkumulasiTahun'], 0, ',', '.') . '" style="border-left: 1px solid gray;">' . number_format($rowk2['AkumulasiTahun'], 0, ',', '.') . '</td></tr>';
                            }
                        }
                    }
                }
                ?>

                <tr style="font-weight: 500 !important;">
                    <td><b>Total</b></td>
                    <?php
                    // HARIAN TF&CASH
                    if ($gettipeakun == 'superuser' || $gettipeakun == 'Manager' ||  $gettipeakun == 'Admin' ||  $user == $specialaccess) {
                        $getdata = mysqli_query($konek, "SELECT SUM(Nominal) as HarianTF FROM kas_masuk 
                        INNER JOIN metode ON metode.Id=kas_masuk.Id_Metode
                        INNER JOIN kantor ON kantor.Id_User=kas_masuk.Id_Fundraiser
                        WHERE kantor.Kantor = '$getkantor' AND Tanggal = '$prevday' AND metode.Metode_Pembayaran NOT LIKE 'Non Cash';");
                        while ($data = mysqli_fetch_array($getdata)) {
                            echo '<td style="border-left: 1px solid gray;"><b>' . number_format($data['HarianTF'], 0, ',', '.') . '</b></td>';
                        }
                    }
                    // HARIAN NON CASH
                    if ($gettipeakun == 'superuser' || $gettipeakun == 'Manager' ||  $gettipeakun == 'Admin' ||  $user == $specialaccess) {
                        $getdata = mysqli_query($konek, "SELECT SUM(Nominal) as HarianNonCash FROM kas_masuk  
                        INNER JOIN metode ON metode.Id=kas_masuk.Id_Metode
                        INNER JOIN kantor ON kantor.Id_User=kas_masuk.Id_Fundraiser
                        WHERE kantor.Kantor = '$getkantor' AND Tanggal = '$prevday' AND metode.Metode_Pembayaran LIKE 'Non Cash';");
                        while ($data = mysqli_fetch_array($getdata)) {
                            echo '<td><b>' . number_format($data['HarianNonCash'], 0, ',', '.') . '</b></td>';
                        }
                    }
                    // PERIODE TF
                    if ($gettipeakun == 'superuser' || $gettipeakun == 'Manager' ||  $gettipeakun == 'Admin' ||  $user == $specialaccess) {
                        $getdata = mysqli_query($konek, "SELECT SUM(Nominal) as PeriodeTF FROM kas_masuk    
                        INNER JOIN metode ON metode.Id=kas_masuk.Id_Metode
                        INNER JOIN kantor ON kantor.Id_User=kas_masuk.Id_Fundraiser
                        WHERE kantor.Kantor = '$getkantor' AND Tanggal >= '$prevperiod' AND Tanggal <= '$nextperiod' AND metode.Metode_Pembayaran NOT LIKE '%Cash%';");
                        while ($data = mysqli_fetch_array($getdata)) {
                            echo '<td style="border-left: 1px solid gray;"><b>' . number_format($data['PeriodeTF'], 0, ',', '.') . '</b></td>';
                        }
                    }
                    // PERIODE CASH
                    if ($gettipeakun == 'superuser' || $gettipeakun == 'Manager' ||  $gettipeakun == 'Admin' ||  $user == $specialaccess) {
                        $getdata = mysqli_query($konek, "SELECT SUM(Nominal) as PeriodeCash FROM kas_masuk    
                        INNER JOIN metode ON metode.Id=kas_masuk.Id_Metode
                        INNER JOIN kantor ON kantor.Id_User=kas_masuk.Id_Fundraiser
                        WHERE kantor.Kantor = '$getkantor' AND Tanggal >= '$prevperiod' AND Tanggal <= '$nextperiod' AND metode.Metode_Pembayaran LIKE 'Cash%';");
                        while ($data = mysqli_fetch_array($getdata)) {
                            echo '<td><b>' . number_format($data['PeriodeCash'], 0, ',', '.') . '</b></td>';
                        }
                    }
                    // PERIODE NON CASH
                    if ($gettipeakun == 'superuser' || $gettipeakun == 'Manager' ||  $gettipeakun == 'Admin' ||  $user == $specialaccess) {
                        $getdata = mysqli_query($konek, "SELECT SUM(Nominal) as PeriodeNonCash FROM kas_masuk    
                        INNER JOIN metode ON metode.Id=kas_masuk.Id_Metode
                        INNER JOIN kantor ON kantor.Id_User=kas_masuk.Id_Fundraiser
                        WHERE kantor.Kantor = '$getkantor' AND Tanggal >= '$prevperiod' AND Tanggal <= '$nextperiod' AND metode.Metode_Pembayaran LIKE 'Non Cash';");
                        while ($data = mysqli_fetch_array($getdata)) {
                            echo '<td><b>' . number_format($data['PeriodeNonCash'], 0, ',', '.') . '</b></td>';
                        }
                    }
                    // PERIODE TOTAL
                    if ($gettipeakun == 'superuser' || $gettipeakun == 'Manager' ||  $gettipeakun == 'Admin' ||  $user == $specialaccess) {
                        $getdata = mysqli_query($konek, "SELECT SUM(Nominal) as PeriodeTotal FROM kas_masuk    
                        INNER JOIN metode ON metode.Id=kas_masuk.Id_Metode
                        INNER JOIN kantor ON kantor.Id_User=kas_masuk.Id_Fundraiser
                        WHERE kantor.Kantor = '$getkantor' AND Tanggal >= '$prevperiod' AND Tanggal <= '$nextperiod';");
                        while ($data = mysqli_fetch_array($getdata)) {
                            echo '<td style="border-left: 1px solid gray;"><b>' . number_format($data['PeriodeTotal'], 0, ',', '.') . '</b></td>';
                        }
                    }
                    // BULAN LALU
                    if ($gettipeakun == 'superuser' || $gettipeakun == 'Manager' ||  $gettipeakun == 'Admin' ||  $user == $specialaccess) {
                        $getdata = mysqli_query($konek, "SELECT SUM(Nominal) as BulanLalu FROM kas_masuk    
                        INNER JOIN metode ON metode.Id=kas_masuk.Id_Metode
                        INNER JOIN kantor ON kantor.Id_User=kas_masuk.Id_Fundraiser
                        WHERE kantor.Kantor = '$getkantor' AND Tanggal >= '$prevperiodlalu' AND Tanggal <= '$nextperiodlalu';");
                        while ($data = mysqli_fetch_array($getdata)) {
                            echo '<td style="border-left: 1px solid gray;"><b>' . number_format($data['BulanLalu'], 0, ',', '.') . '</b></td>';
                        }
                    }
                    // AKUMULASI TAHUNAN
                    if ($gettipeakun == 'superuser' || $gettipeakun == 'Manager' ||  $gettipeakun == 'Admin' ||  $user == $specialaccess) {
                        $getdata = mysqli_query($konek, "SELECT SUM(Nominal) as AkumulasiTahunan FROM kas_masuk    
                        INNER JOIN metode ON metode.Id=kas_masuk.Id_Metode
                        INNER JOIN kantor ON kantor.Id_User=kas_masuk.Id_Fundraiser
                        WHERE kantor.Kantor = '$getkantor' AND Tanggal >= '2021-12-26' AND Tanggal <= '2022-12-20';");
                        while ($data = mysqli_fetch_array($getdata)) {
                            echo '<td style="border-left: 1px solid gray;"><b>' . number_format($data['AkumulasiTahunan'], 0, ',', '.') . '</b></td>';
                        }
                    }
                    ?>
                </tr>
            </tbody>
        </table>
    </div>
</div>