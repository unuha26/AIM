<div class="card">
    <div class="card-header border-0">
        <h3 class="card-title">Detail Daftar Donatur</h3>
    </div>
    <div class="card-body table-responsive">
        <table class="table table-striped table-valign-middle table-sm DynamicVerticalScroll">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Nama Donatur</th>
                    <th>Nomor HP</th>
                    <th>Nama Fundraiser</th>
                    <th>Total Transaksi</th>
                    <th>Total Donasi</th>
                    <th>Tanggal Daftar</th>
                    <th>Kategori</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // $user = $_SESSION['usernameam'];
                if ($gettipeakun == 'superuser' || $user == $specialaccess) {
                    $query = "SELECT DISTINCT user_donatur.Id, user_donatur.Nama_Donatur, user_donatur.CP, fundraiser.Nama as Nama_Fundraiser, (SELECT SUM(kas_masuk.Nominal) FROM kas_masuk WHERE kas_masuk.Id_Donatur = donatur.Id_Donatur AND kas_masuk.Id_Fundraiser = donatur.Id_Fundaiser) AS Total_Donasi, (SELECT COUNT(*) FROM kas_masuk WHERE kas_masuk.Id_Donatur = donatur.Id_Donatur AND kas_masuk.Id_Fundraiser = donatur.Id_Fundaiser) AS Total_Transaksi, user_donatur.Tanggal_Daftar, user_donatur.Kategori
                                FROM donatur
                                INNER JOIN user_donatur ON user_donatur.Id=donatur.Id_Donatur
                                INNER JOIN fundraiser ON fundraiser.Id_User=donatur.Id_Fundaiser
                                INNER JOIN kas_masuk ON kas_masuk.Id_Donatur = donatur.Id_Donatur  
                                ORDER BY fundraiser.Nama;";
                } else if ($gettipeakun == 'Manager' ||  $gettipeakun == 'Admin') {
                    $query = "SELECT DISTINCT user_donatur.Id, user_donatur.Nama_Donatur, user_donatur.CP, fundraiser.Nama as Nama_Fundraiser, (SELECT SUM(kas_masuk.Nominal) FROM kas_masuk WHERE kas_masuk.Id_Donatur = donatur.Id_Donatur AND kas_masuk.Id_Fundraiser = donatur.Id_Fundaiser) AS Total_Donasi, (SELECT COUNT(*) FROM kas_masuk WHERE kas_masuk.Id_Donatur = donatur.Id_Donatur AND kas_masuk.Id_Fundraiser = donatur.Id_Fundaiser) AS Total_Transaksi, user_donatur.Tanggal_Daftar, user_donatur.Kategori
                                FROM donatur
                                INNER JOIN user_donatur ON user_donatur.Id=donatur.Id_Donatur
                                INNER JOIN fundraiser ON fundraiser.Id_User=donatur.Id_Fundaiser
                                INNER JOIN kas_masuk ON kas_masuk.Id_Donatur = donatur.Id_Donatur
                                INNER JOIN kantor ON kantor.Id_User=kas_masuk.Id_Fundraiser
                                WHERE kantor.Kantor = '$getkantor' ORDER BY fundraiser.Nama;";
                }
                $getdata = mysqli_query($konek, "$query");
                while ($data = mysqli_fetch_array($getdata)) {
                    echo '<tr>
                    <td><a href="edit?Id=' . $data["Id"] . '&Page=donatur">' . $data["Id"] . '</a></td>
                    <td>' . $data['Nama_Donatur'] . '</td>
                    <td>' . $data['CP'] . '</td>
                    <td>' . $data['Nama_Fundraiser'] . '</td>
                    <td>Rp ' . number_format($data['Total_Donasi'], 0, ',', '.') . '</td>
                    <td>' . $data['Total_Transaksi'] . 'x</td>
                    <td>' . $data['Tanggal_Daftar'] . '</td>
                    <td>' . $data['Kategori'] . '</td>
                    </tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
</div>