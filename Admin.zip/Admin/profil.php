<?php
ini_set('session.gc_maxlifetime', 2678400);
ob_start();
session_start();
require_once("include/config.php");
// cek user login dengan session yg benar
if (!isset($_SESSION['usernameam']) or !isset($_SESSION['csam'])) {
  header("Location: login");
  die();
} else {
  $usernameam = $_SESSION['usernameam'];
  $sessionam = $_SESSION['csam'];
  $ceksession = mysqli_query($konek, "select * from user where username='$usernameam'");
  $xceksession = mysqli_fetch_array($ceksession);
  $truesession = $xceksession['session'];
  if ($_SESSION['csam'] <> $truesession) {
    header("Location: login");
    die();
  } else {
    // ini yang dipakai
    include("include/header.php");
    $xdata = mysqli_query($konek, "SELECT * FROM `user` WHERE Username = '$usernameam'");
    $getdata = mysqli_fetch_array($xdata);
    $getnama = $getdata['Nama'];
    $nohp = $getdata['NoHp'];
    $pass = $getdata['Password'];
    $username = $getdata['Username'];
    $tipeakun = $getdata['Tipe_Akun'];
    $pendaftar = $getdata['Pendaftar'];
    $id = $getdata['Id'];

    $xdatak = mysqli_query($konek, "SELECT * FROM `kantor` WHERE Id_User = '$id'");
    $getdatak = mysqli_fetch_array($xdatak);
    $kantor = $getdatak['Kantor'];

    $xdatam = mysqli_query($konek, "SELECT * FROM `fundraiser` WHERE Id_User = '$id'");
    $getdatam = mysqli_fetch_array($xdatam);
    $mitra = $getdatam['Mitra'];

    // pilihfpindah tambahfundraiser tambahmitra



    if (isset($_POST['submit'])) {

      $nama = $_POST['nama'];
      $nohp = $_POST['nohp'];
      $password = trim(stripslashes(strip_tags(htmlspecialchars(mysqli_real_escape_string($konek, md5($_POST['password']))))));
      $password2 = trim(stripslashes(strip_tags(htmlspecialchars(mysqli_real_escape_string($konek, md5($_POST['password2']))))));


      if (!$nama || !$nohp || !$password || !$password2) {
        $pesan = "<span>Lengkapi data dengan benar</span>";
      } else {
        // if ($username != $tusername)
        if ($password == $password2 || $pass != $password) {
          $pesan = "Password baru harus berbeda dari password lama";
        } else if ($pass == $password) {
          $insert = mysqli_query($konek, "UPDATE user SET `Nama`='$nama', `NoHp`='$nohp', `Password`='$password2' WHERE `Id`='$id'");
          $pesan = "Update Data Berhasil!";
        }
      }
    }
?>


    <body class="hold-transition">
      <div class="wrapper">

        <?php
        include("include/menu.php");
        include("func/terbilang.php");
        ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
          <!-- Main content -->
          <div class="content" style="padding: 20px;">
            <div class="container-fluid">
              <div class="row">
                <div class="col-lg-12">

                  <div class="card card-primary">
                    <div class="card-header">
                      <h3 class="card-title">Edit Profil</h3>

                      <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                          <i class="fas fa-minus"></i>
                        </button>
                      </div>
                    </div>
                    <form role="form" method="POST" action="profil" autocomplete="off">
                      <div class="card-body">
                        <?php
                        if (isset($_POST['submit'])) {
                          echo $pesan;
                        }

                        ?>
                        <div class="form-group">
                          <label for="donasinohp">Nama</label>
                          <input type="text" name="nama" class="form-control" value="<?php echo $getnama; ?>">
                        </div>

                        <div class="form-group">
                          <label for="donasinohp">No HP</label>
                          <input type="number" name="nohp" class="form-control" value="<?php echo $nohp; ?>">
                        </div>

                        <div class="form-group">
                          <label for="donasinohp">Username</label>
                          <input type="text" name="username" class="form-control" value="<?php echo $username; ?>" disabled>
                        </div>

                        <div class="form-group">
                          <label for="donasinohp">Password Lama</label>
                          <input type="password" name="password" class="form-control">
                        </div>

                        <div class="form-group">
                          <label for="donasinohp">Password Baru</label>
                          <input type="password" name="password2" class="form-control">
                        </div>

                        <div class="form-group">
                          <label for="donasinohp">Tipe Akun</label>
                          <input type="text" name="tipeakun" class="form-control" value="<?php echo $tipeakun; ?>" disabled>
                        </div>

                        <div class="form-group">
                          <label for="donasinohp">Pendaftar</label>
                          <input type="text" name="pendaftar" class="form-control" value="<?php echo $pendaftar; ?>" disabled>
                        </div>

                        <div class="form-group">
                          <label for="donasinohp">Kantor</label>
                          <input type="text" name="kantor" class="form-control" value="<?php echo $kantor; ?>" disabled>
                        </div>

                        <div class="form-group">
                          <label for="donasinohp">Mitra dari</label>
                          <input type="text" name="mitra" class="form-control" value="<?php echo $mitra; ?>" disabled>
                        </div>

                        <div class="form-group">
                          <input type="submit" name="submit" value="Simpan" class="btn btn-success float-right">
                        </div>
                      </div>
                    </form>
                    <!-- /.card-body -->
                  </div>
                </div>
                <!-- /.col-md-6 -->
              </div>
              <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
          </div>
          <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->

        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
          <!-- Control sidebar content goes here -->
        </aside>
        <!-- /.control-sidebar -->
      </div>
      <!-- ./wrapper -->

  <?php
  }
}
include("include/footer.php");
  ?>
    </body>

    </html>