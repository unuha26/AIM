<?php
session_start();
require_once("include/config.php");
$getIdnota = $_GET['Id'];
$xdataid = mysqli_query($konek, "SELECT kas_masuk.Id, kas_masuk.Tanggal, user_donatur.Nama_Donatur as AtasNama, kas_masuk.AtasNama as AtasNama2, user_donatur.CP as CP, akad.Akad, kas_masuk.Nominal, kas_masuk.Keterangan, kas_masuk.Input_by as Nama FROM kas_masuk
                                    INNER JOIN user_donatur ON user_donatur.Id=kas_masuk.Id_Donatur
                                    INNER JOIN akad ON akad.Id=kas_masuk.Id_Akad
                                    WHERE kas_masuk.Id ='$getIdnota'");
$getdataid = mysqli_fetch_array($xdataid);
$inputby = $getdataid['Nama'];
// require_once("plugins/dompdf/dompdf_config.inc.php");
include("func/terbilang.php");
if ($getdataid['AtasNama'] != $getdataid['AtasNama2']) {
    $atasnama = $getdataid['AtasNama2'];
}
$fndonatur = explode(" ", $getdataid['AtasNama']);
$fnadmin = explode(" ", $getdataid['Nama']);
$xdataidu = mysqli_query($konek, "SELECT `Username` FROM `user` WHERE `Nama` ='$inputby'");
$getdataidu = mysqli_fetch_array($xdataidu);
$ttd = $getdataidu['Username'];
error_reporting(E_ERROR);
// 
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kwitansi_<?php echo $getdataid['Tanggal'] . '_' . $getdataid['AtasNama'] . '_' . $getdataid['Id'] ?></title>
    <link type="text/css" href="dist/css/dompdf.css" rel="stylesheet" />
</head>

<body>
    <div class="w-50">
        <div class="box">
            <div class="box-in">
                <table>
                    <tr>
                        <td>
                            <img src="dist/img/aimhitam.png" class="logo">
                        </td>
                        <td>
                            <p class="alamat"><span class="block" style="margin-right: 5px;">Jl. Tlogobayem No.716 </span><span class="block" style="margin-right: 5px;"> Semarang Selatan - Kota Semarang </span><span class="block">Telp. 082211870001</span></p>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        <div class="box">
            <div class="box-in">
                <h3 class="title">DATA PENYETOR</h3>
                <table class="table">
                    <tr>
                        <td style="width: 80px;">Nama</td>
                        <td>:</td>
                        <td><?php echo $getdataid['AtasNama'] ?></td>
                    </tr>
                    <tr>
                        <td>Alamat</td>
                        <td>:</td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Telp/Hp</td>
                        <td>:</td>
                        <td><?php
                            if ($getdataid['CP'] > 10000) {
                                echo $getdataid['CP'];
                            }
                            ?></td>
                    </tr>
                    <tr>
                        <td>NPWP</td>
                        <td>:</td>
                        <td></td>
                    </tr>
                </table>
            </div>
        </div>
        <div class="box">
            <div class="box-in">
                <table class="table" style="padding: 10px 15px 0;">
                    <tr>
                        <td style=" width: 200px; " rowspan="3">
                            <p class="small">
                                <b>Rek. Aksi Insan Mulia<br></b>
                                Muamalat (147) : 5480006498 <br>
                                BSI (451) : 8585888851 <br>
                                BRI (002) : 6051-0101-8213-539 <br>
                                <b>E-Wallet AIM</b><br>
                                Ovo, Gopay, Dana, Shoopepay <br>
                                0822-1187-0005</span>
                        </td>
                        <td colspan="2">
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div style="position: relative;">
                                <img src="dist/img/aimhitam.png" style="width: 220px;opacity: .3;margin: 0 25px;">
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td style=" text-align: center;  vertical-align: sub;">
                            <div style="position: relative;">
                                <img src="dist/img/ttd/<?php echo $ttd ?>.png" style="height: 100px;position: absolute;bottom: -40px;left: 50%;margin-right: -50%;transform: translate(-50%, -50%);">
                                <span>( <?php echo $fnadmin[0] ?> )</span>
                            </div>
                        </td>
                        <td style="text-align: center; vertical-align: sub;">
                            <div>
                                <span>( <?php echo $fndonatur[0] . ' ' . $fndonatur[1] ?> )</span>
                            </div>
                        </td>
                    </tr>
                </table>
                <img src="">
            </div>
        </div>
    </div>
    <div class="w-50">
        <div class="box pr-15">
            <div class="box-in">
                <div>
                    <h3 class="title">BUKTI PENERIMAAN SEDEKAH INFAQ</h3>
                    <table class="table" style="padding-bottom: 5px;">
                        <tr>
                            <td>Nomor : <?php echo $getdataid['Id'] ?></td>
                            <td>Tanggal : <?php echo $getdataid['Tanggal'] ?></td>
                        </tr>
                    </table>
                    <div class="box" style="padding: 0 15px;">
                        <table class="table table-border">
                            <tr>
                                <th class="l">Nomor</th>
                                <th class="l">Jenis Setoran</th>
                                <th class="l">Jumlah</th>
                            </tr>
                            <tr>
                                <td class="l">
                                    1.
                                </td>
                                <td class="l"><?php echo $getdataid['Akad'] ?></td>
                                <td class="l"><?php echo 'Rp ' . number_format($getdataid['Nominal'], 0, ',', '.') ?></td>
                            </tr>
                            <?php
                            if ($getdataid['Keterangan'] != '') {
                                echo '<tr>
                                <td class="l" colspan="3">Keterangan : ' . $getdataid['Keterangan'] . '</td>
                                </tr>';
                            }
                            if ($atasnama != '') {
                                echo '
                                <tr>
                                <td class="l" colspan="3">Atas Nama : ' . $atasnama . '</td>
                                </tr>';
                            }
                            ?>
                        </table>
                    </div>
                    <div class="block p-15">
                        <span class="small"><b>Terbilang</b></span>
                        <p class="terbilang"><?php echo terbilang($getdataid['Nominal']) ?></p>
                        <img src="dist/img/arabdua.png" style="width: 100%;">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        window.print();
    </script>
</body>

</html>