<?php
ini_set('session.gc_maxlifetime', 2678400);
ob_start();
session_start();
require_once("include/config.php");
require_once("include/gettipeakun.php");
// cek user login dengan session yg benar
if (!isset($_SESSION['usernameam']) or !isset($_SESSION['csam'])) {
  header("Location: login");
  die();
} else {
  $usernameam = $_SESSION['usernameam'];
  $sessionam = $_SESSION['csam'];
  $ceksession = mysqli_query($konek, "select * from user where username='$usernameam'");
  $xceksession = mysqli_fetch_array($ceksession);
  $truesession = $xceksession['session'];
  if ($_SESSION['csam'] <> $truesession) {
    header("Location: login");
    die();
  } else {
    // ini yang dipakai
    include("include/header.php");
    $xdata = mysqli_query($konek, "select * from user where Username='$usernameam'");
    $getdata = mysqli_fetch_array($xdata);
    $getnama = $getdata['Nama'];
    // pilihfpindah tambahfundraiser tambahmitra

    $getpage = $_GET['Page'];
    $getId = $_GET['Id'];
    $xdataid = mysqli_query($konek, "SELECT user_donatur.CP, kas_masuk.AtasNama, user_donatur.Kategori, kas_masuk.Nominal, kas_masuk.Id, kas_masuk.Id_Metode, kas_masuk.Id_Fundraiser, kas_masuk.Id_Akad, kas_masuk.Tanggal, kas_masuk.Keterangan, kas_masuk.Id_Donatur FROM `kas_masuk`
    INNER JOIN user_donatur ON user_donatur.Id = kas_masuk.Id_Donatur
    WHERE kas_masuk.Id ='$getId'");
    $getdataid = mysqli_fetch_array($xdataid);

    $xdataidd = mysqli_query($konek, "SELECT * FROM `user_donatur` WHERE Id ='$getId'");
    $getdataidd = mysqli_fetch_array($xdataidd);

    // DELETE FROM `kas_masuk` WHERE `kas_masuk`.`Id` = 69
    if (isset($_POST['submit2'])) {
      $thisidget = $_POST['getid'];
      $insert = mysqli_query($konek, "DELETE FROM `kas_masuk` WHERE `kas_masuk`.`Id` = '$thisidget';");
      if ($insert) {
        header("location:view");
      }
    }
    if (isset($_POST['submit'])) {

      $iddonatur = $_POST['iddonatur'];
      $donasiketerangan = $_POST['donasiketerangan'];
      $donasinohp = $_POST['donasinohp'];
      $donasikategori = $_POST['donasikategori'];
      $donasinama = $_POST['donasinama'];
      $donasinominal = $_POST['donasinominal'];
      $donasibank = $_POST['donasibank'];
      $donasifundraiser = $_POST['donasifundraiser'];
      $donasiprogram = $_POST['donasiprogram'];
      $datedonasi = $_POST['datedonasi'];
      $thisidget = $_POST['getid'];

      $ceksekarang = date("Y-m-d");
      $insert = mysqli_query($konek, "UPDATE `kas_masuk` SET `Keterangan` = '$donasiketerangan', `Nominal` = '$donasinominal', `Id_Metode` = '$donasibank', `Id_Fundraiser` = '$donasifundraiser' , `Id_Akad` = '$donasiprogram' , `Tanggal` = '$datedonasi' WHERE `kas_masuk`.`Id` = '$thisidget';");
      $insert1 = mysqli_query($konek, "INSERT INTO `donatur` VALUES ('', '$iddonatur', '$donasifundraiser');");
      if ($insert) {
        header("location:view");
      }
    }
    if (isset($_POST['submitdonatur'])) {
      $namadonatur = $_POST['namadonatur'];
      $cp = $_POST['cp'];
      $kategori = $_POST['kategori'];
      $iddonatur = $_POST['iddonatur'];
      $insert = mysqli_query($konek, "UPDATE `user_donatur` SET `Nama_Donatur` = '$namadonatur', `CP` = '$cp', `Kategori` = '$kategori' WHERE `Id` = '$iddonatur';");
      if ($insert) {
        header("location:view");
      }
    }

?>


    <body class="hold-transition">
      <div class="wrapper">

        <?php
        include("include/menu.php");
        include("func/terbilang.php");
        ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
          <!-- Main content -->
          <div class="content" style="padding: 20px;">
            <div class="container-fluid">
              <div class="row">
                <div class="col-12">
                  <?php
                  if ($gettipeakun == 'superuser' ||  $gettipeakun == 'Manager' ||  $gettipeakun == 'Admin') {
                    // KAS MASUK
                    if ($getpage == 'kasmasuk') {
                      require_once("content/kasmasukedit13.php");
                    }
                    // DONATUR
                    if ($getpage == 'donatur') {
                      require_once("content/donaturedit19.php");
                    }
                  } else header("location: view");
                  ?>
                </div>
                <!-- /.col-md-6 -->
              </div>
              <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
          </div>
          <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->

        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
          <!-- Control sidebar content goes here -->
        </aside>
        <!-- /.control-sidebar -->
      </div>
      <!-- ./wrapper -->

  <?php
  }
}
include("include/footer.php");
  ?>
  <script>
    function getdata_nama(type) {
      var cek = $("#donasinohp").val();
      $.ajax({
        url: 'func/cekname.php',
        data: 'donasinohp=' + cek,
        type: 'GET',
        dataType: 'html',
        success: function(msg) {
          $("#thisname").html(msg);
        }
      });

    }

    function getdata_namaf(type) {
      var cek = $("#thisnamelist").val();
      $.ajax({
        url: 'func/ceknamef.php',
        data: 'thisnamelist=' + cek,
        type: 'GET',
        dataType: 'html',
        success: function(msg) {
          $("#donasifundraiserlist").html(msg);
        }
      });

    }

    function getdata_idf(type) {
      var cek = $("#donasinanaslist").val();
      $.ajax({
        url: 'func/cekidf.php',
        data: 'donasinanaslist=' + cek,
        type: 'GET',
        dataType: 'html',
        success: function(msg) {
          $("#donasinohp2").html(msg);
        }
      });

    }
  </script>
    </body>

    </html>