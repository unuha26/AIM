<?php
ini_set('session.gc_maxlifetime', 2678400);
ob_start();
session_start();
require_once("include/config.php");
require_once("include/gettipeakun.php");
// cek user login dengan session yg benar
if (!isset($_SESSION['usernameam']) or !isset($_SESSION['csam'])) {
    header("Location: login");
    die();
} else {
    $usernameam = $_SESSION['usernameam'];
    $sessionam = $_SESSION['csam'];
    $ceksession = mysqli_query($konek, "select * from user where username='$usernameam'");
    $xceksession = mysqli_fetch_array($ceksession);
    $truesession = $xceksession['session'];
    if ($_SESSION['csam'] <> $truesession) {
        header("Location: login");
        die();
    } else {
        // ini yang dipakai
        include("include/header.php");
        $xdata = mysqli_query($konek, "select * from user where Username='$usernameam'");
        $getdata = mysqli_fetch_array($xdata);
        $getnama = $getdata['Nama'];

        $day = date('d');
        // $day = 1;
        $day1 = $day - 1;
        $month = date('m');
        // $month = 12;
        $years = date('Y');
        // $prevday = $years . '-' . $month . '-' . $day1;
        $prevday = $years . '-' . $month . '-' . $day;



?>

        <style>
            .setFundraiser {
                display: none;
            }
        </style>

        <body class="hold-transition">
            <div class="wrapper">

                <?php
                include("include/menu.php");
                include("func/terbilang.php");
                include("func/detailcapaian.php");
                ?>

                <!-- Content Wrapper. Contains page content -->
                <div class="content-wrapper">
                    <!-- Main content -->
                    <div class="content" style="padding: 20px;">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-lg-12">
                                    <!-- CAPAIAN HARIAN -->
                                    <?php
                                    if ($gettipeakun == 'superuser' ||  $gettipeakun == 'Manager' ||  $gettipeakun == 'Admin' ||  $gettipeakun == 'SDM') {
                                        require_once("content/capaianharian08.php");
                                    }
                                    ?>

                                    <!-- KAS MASUK -->
                                    <?php
                                    if ($gettipeakun == 'superuser' ||  $gettipeakun == 'Manager' ||  $gettipeakun == 'Admin' ||  $gettipeakun == 'SDM') {
                                        require_once("content/kasmasuk09.php");
                                    }
                                    ?>

                                    <!-- MUTASI -->
                                    <?php
                                    if ($gettipeakun == 'superuser' ||  $gettipeakun == 'Manager' ||  $gettipeakun == 'Admin') {
                                        require_once("content/kasmasuk09.php");
                                    }
                                    ?>

                                    <!-- CAPAIAN HARIAN PROGRAM -->
                                    <?php
                                    if ($gettipeakun == 'superuser' ||  $gettipeakun == 'Manager' ||  $gettipeakun == 'Admin') {
                                        require_once("content/capaianharianprogram14.php");
                                    }
                                    ?>

                                    <!-- Daftar Kas -->
                                    <?php
                                    if ($gettipeakun == 'superuser' ||  $gettipeakun == 'Manager' ||  $gettipeakun == 'Admin') {
                                        require_once("content/daftarkas15.php");
                                    }
                                    ?>

                                    <!-- DAFTAR FUNDRAISER -->
                                    <?php
                                    if ($gettipeakun == 'superuser' ||  $gettipeakun == 'Manager' ||  $gettipeakun == 'Admin') {
                                        require_once("content/daftarfundraiser10.php");
                                    }
                                    ?>

                                    <!-- DAFTAR DONATUR -->
                                    <?php
                                    if ($gettipeakun == 'superuser' ||  $gettipeakun == 'Manager' ||  $gettipeakun == 'Admin' ||  $gettipeakun == 'SDM') {
                                        require_once("content/daftardonatur11.php");
                                    }
                                    ?>
                                    <!-- DAFTAR AKUN -->
                                    <?php
                                    if ($gettipeakun == 'superuser' ||  $gettipeakun == 'Manager' ||  $gettipeakun == 'Admin') {
                                        require_once("content/daftarakun12.php");
                                    }
                                    ?>
                                </div>
                                <!-- /.col-md-6 -->
                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.container-fluid -->
                    </div>
                    <!-- /.content -->
                </div>
                <!-- /.content-wrapper -->

                <!-- Control Sidebar -->
                <aside class="control-sidebar control-sidebar-dark">
                    <!-- Control sidebar content goes here -->
                </aside>
                <!-- /.control-sidebar -->
            </div>
            <!-- ./wrapper -->

            <script>
                $(function() {
                    $("#DataTable1").DataTable({
                        "responsive": true,
                        "lengthChange": false,
                        "autoWidth": false,
                        "buttons": ["copy", "csv", "excel", "pdf", "print"]
                    }).buttons().container().appendTo('#DataTable1_wrapper .col-md-6:eq(0)');
                    $('#example1').DataTable({
                        "paging": true,
                        "lengthChange": false,
                        "searching": false,
                        "ordering": true,
                        "info": true,
                        "autoWidth": false,
                        "responsive": true,
                    });

                });

                // function getdata_nama(type) {
                //     var cek = $("#donasinohp").val();
                //     $.ajax({
                //         url: 'func/cekname.php',
                //         data: 'donasinohp=' + cek,
                //         type: 'GET',
                //         dataType: 'html',
                //         success: function(msg) {
                //             $("#thisname").html(msg);
                //         }
                //     });

                // }
            </script>

    <?php
    }
}
include("include/footer.php");
    ?>
        </body>

        </html>