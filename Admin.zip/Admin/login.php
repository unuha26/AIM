<?php
ob_start();
session_start();
error_reporting(E_ERROR);
require_once("include/config.php");
// cek user login dengan session yg benar
if (isset($_SESSION['usernameam'])) {
  $usernameam = $_SESSION['usernameam'];
  $sessionam = $_SESSION['csam'];
  $ceksession = mysqli_query($konek, "select * from user where Username='$usernameam'");
  $xceksession = mysqli_fetch_array($ceksession);
  $truesession = $xceksession['session'];
  if ($_SESSION['csam'] == $truesession) {
    header("Location: index ");
    die();
  }
}

// cek data yang sudah di submit
if (isset($_POST['submit'])) {
  $username = trim(stripslashes(strip_tags(htmlspecialchars(mysqli_real_escape_string($konek, $_POST['username'])))));
  $password = trim(stripslashes(strip_tags(htmlspecialchars(mysqli_real_escape_string($konek, md5($_POST['password']))))));
  if (strpbrk($username, "#$%^&*()+=-[]';/{}|:<>?~") === false) {
    $cekuser = mysqli_query($konek, "select * from user where Username='$username'");
    $fcekuser = mysqli_fetch_array($cekuser);
    $fpass = $fcekuser['Password'];
    $xcekuser = mysqli_num_rows($cekuser);
    if ($xcekuser == 0) {
      $pesan = "<span>Username atau Password Anda salah</span>";
    } else {
      if ($password == $fpass) {
        $_SESSION['usernameam'] = $username;
        $csam = rand(100000000, 999999999);
        $_SESSION['csam'] = $csam;
        $updatesession = mysqli_query($konek, "update user set session='$csam' where Username='$username'");
        // $updateip = mysqli_query($konek, "update user set ip='$ip' where username='$username'");
        // $updatelastlogin = mysqli_query($konek, "update user set lastlogin='$sekarang' where username='$username'");
        $pesan = "<span>Berhasil login, Mohon tunggu sebentar...</span><script>window.location = '';</script>";
      } else {
        $pesan = "<span>Username atau Password Anda salah</span>";
      }
    }
  } else {
    $pesan = "<span>Dilarang menggunakan simbol di username</span>";
  }
}

include("include/header.php");
?>

<body class="hold-transition login-page">
  <div class="login-box">
    <div class="login-logo">
      <a href="admin.html"><b>Login</b></a>
    </div>
    <!-- /.login-logo -->
    <div class="card">
      <div class="card-body login-card-body">
        <p class="login-box-msg">Sign in to start your session</p>

        <?php

        if (isset($_POST['submit'])) {
          echo $pesan;
        } elseif (isset($_GET['error']) == "yes") {
          echo "<span>Silahkan login terlebih dahulu.</span>";
        }
        ?>

        <form role="form" method="POST" action="login" autocomplete="off">
          <div class="input-group mb-3">
            <input type="text" class="form-control" name="username" placeholder="Username" onkeyup="return forceLower(this);">
            <div class="input-group-append">
              <div class="input-group-text">
                <span class="fas fa-envelope"></span>
              </div>
            </div>
          </div>
          <div class="input-group mb-3">
            <input type="password" name="password" class="form-control" placeholder="Password">
            <div class="input-group-append">
              <div class="input-group-text">
                <span class="fas fa-lock"></span>
              </div>
            </div>
          </div>
          <div class="row">
            <!-- /.col -->
            <div class="col-12">
              <button name="submit" type="submit" class="btn btn-primary btn-block">Sign In</button>
            </div>
            <!-- /.col -->
          </div>
        </form>
      </div>
      <!-- /.login-card-body -->
    </div>
  </div>
  <!-- /.login-box -->
  <?php
  include("include/footer.php");
  ?>
</body>

</html>