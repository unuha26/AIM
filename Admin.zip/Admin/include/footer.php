<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE -->
<script src="dist/js/adminlte.js"></script>

<!-- OPTIONAL SCRIPTS -->
<script src="plugins/chart.js/Chart.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="dist/js/pages/dashboard3.js"></script>
<!-- DataTables  & Plugins -->
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="plugins/jszip/jszip.min.js"></script>
<script src="plugins/pdfmake/pdfmake.min.js"></script>
<script src="plugins/pdfmake/vfs_fonts.js"></script>
<script src="plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.colVis.min.js"></script>

<script>
  jQuery(document).ready(function($) {
    $(".setMitra").html("Mitra ");
    $(".setPublik").html("Publik ");

    // var a = $("td").val();
    // if (a = "Rp 0") {
    //   $("td").html("-");
    //   return;
    // } else {
    //   $("td").val() = $('td').val();
    // }
    $(".Set0").html("-");
    // var a = $("td").val();
    // if (a = "Rp 0") {
    //   $("td").html("-");
    // }


    if (window.history && window.history.pushState) {

      $(window).on('popstate', function() {
        var hashLocation = location.hash;
        var hashSplit = hashLocation.split("#!/");
        var hashName = hashSplit[1];

        if (hashName !== '') {
          var hash = window.location.hash;
          if (hash === '') {
            window.location = '/';
            return false;
          }
        }
      });

      window.history.pushState('forward', null, './#');
    }

  });

  function forceLower(strInput) {
    strInput.value = strInput.value.toLowerCase();
  };

  function forceClean(strInput) {
    strInput.value = strInput.value.replace(/[^\d]/g, '');
  };


  // $(function() {
  //   $("#DataTable1").DataTable({
  //     "responsive": true,
  //     "lengthChange": false,
  //     "autoWidth": false,
  //     "buttons": ["copy", "csv", "excel", "pdf", "print"]
  //   }).buttons().container().appendTo('#DataTable1_wrapper .col-md-6:eq(0)');
  //   $('#example1').DataTable({
  //     "paging": true,
  //     "lengthChange": false,
  //     "searching": false,
  //     "ordering": true,
  //     "info": true,
  //     "autoWidth": false,
  //     "responsive": true,
  //   });

  // });
  // $(function() {
  //   $("#DataTable2").DataTable({
  //     "responsive": true,
  //     "lengthChange": false,
  //     "autoWidth": false,
  //     "buttons": ["copy", "csv", "excel", "pdf", "print"]
  //   }).buttons().container().appendTo('#DataTable2_wrapper .col-md-6:eq(0)');
  //   $('#example2').DataTable({
  //     "paging": true,
  //     "lengthChange": false,
  //     "searching": false,
  //     "ordering": true,
  //     "info": true,
  //     "autoWidth": false,
  //     "responsive": true,
  //   });

  // });
  // $(function() {
  //   $("#DataTable3").DataTable({
  //     "responsive": true,
  //     "lengthChange": false,
  //     "autoWidth": false,
  //     "buttons": ["copy", "csv", "excel", "pdf", "print"]
  //   }).buttons().container().appendTo('#DataTable3_wrapper .col-md-6:eq(0)');
  //   $('#example3').DataTable({
  //     "paging": true,
  //     "lengthChange": false,
  //     "searching": false,
  //     "ordering": true,
  //     "info": true,
  //     "autoWidth": false,
  //     "responsive": true,
  //   });

  // });
  // $(function() {
  //   $("#DataTable4").DataTable({
  //     "responsive": true,
  //     "lengthChange": false,
  //     "autoWidth": false,
  //     "buttons": ["copy", "csv", "excel", "pdf", "print"]
  //   }).buttons().container().appendTo('#DataTable4_wrapper .col-md-6:eq(0)');
  //   $('#example4').DataTable({
  //     "paging": true,
  //     "lengthChange": false,
  //     "searching": false,
  //     "ordering": true,
  //     "info": true,
  //     "autoWidth": false,
  //     "responsive": true,
  //   });
  // });

  // $(function() {
  //   $("#DataTable5").DataTable({
  //     "responsive": true,
  //     "lengthChange": false,
  //     "autoWidth": false,
  //     "buttons": ["copy", "csv", "excel", "pdf", "print"]
  //   }).buttons().container().appendTo('#DataTable5_wrapper .col-md-6:eq(0)');
  //   $('#example5').DataTable({
  //     "paging": true,
  //     "lengthChange": false,
  //     "searching": false,
  //     "ordering": true,
  //     "info": true,
  //     "autoWidth": false,
  //     "responsive": true,
  //   });

  // });
  $(function() {
    // $(".downloaddata").DataTable({
    // "responsive": true,
    // "lengthChange": false,
    // "autoWidth": false,
    //   "buttons": ["copy", "csv", "excel", "pdf", "print"]
    // }).buttons().container().appendTo('.downloaddata_wrapper .col-md-6:eq(0)');
    // $('.downloaddata').DataTable({
    //   "paging": true,
    //   "lengthChange": false,
    //   "searching": false,
    //   "ordering": true,
    //   "info": true,
    //   "autoWidth": false,
    //   "responsive": true,
    // });

  });
  // $(document).ready(function() {
  //   $('#dtDynamicVerticalScroll').DataTable({
  //     "scrollY": "70vh",
  //     "scrollCollapse": true,
  //     "buttons": ["copy", "csv", "excel", "pdf", "print"],
  //   }).buttons().container().appendTo('.downloaddata_wrapper .col-md-6:eq(0)');
  //   $('.dataTables_length').addClass('bs-select');
  // });
  $(document).ready(function() {
    $('.DynamicVerticalScroll').DataTable({
      dom: 'Bfrtip',
      "buttons": ["copy", "csv", "excel", "pdf", "print"],
      "scrollY": "70vh",
      "scrollCollapse": true,
    });
    $('.dataTables_length').addClass('bs-select');
  });
</script>
</body>

</html>