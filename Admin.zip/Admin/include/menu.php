<!-- Navbar -->
<?php
include("gettipeakun.php");

?>
<nav class="x-auto main-header navbar navbar-expand navbar-white navbar-light">
  <!-- Left navbar links -->
  <ul class="navbar-nav">
    <li class="nav-item max">
      <a href="index" class="nav-link">Dashboard</a>
    </li>
    <?php
    if ($gettipeakun == 'superuser' ||  $gettipeakun == 'Manager' ||  $gettipeakun == 'Admin') {
      echo '<li class="nav-item max">
            <a href="input" class="nav-link">Input Data</a>
            </li>';
    }
    ?>

    <li class="nav-item max">
      <a href="view" class="nav-link">Lihat Data</a>
    </li>
    <?php
    if ($gettipeakun == 'superuser' ||  $gettipeakun == 'Manager' ||  $gettipeakun == 'Admin') {
      echo '<li class="nav-item max">
            <a href="pengajuan" class="nav-link">Pengajuan</a>
            </li>';
    }
    if ($gettipeakun == 'superuser' ||  $gettipeakun == 'Manager' || $user == $specialaccess) {
      echo '<li class="nav-item max">
              <a href="#" class="nav-link">Bank</a>
            </li>';
    }
    ?>

    <li class="nav-item max">
      <a href="profil" class="nav-link">Profil</a>
    </li>
    <li class="nav-item max">
      <a href="logout" class="nav-link">Logout</a>
    </li>
  </ul>

  <!-- Right navbar links -->
  <ul class="navbar-nav ml-auto">

    <li class="nav-item">
      <a class="nav-link" data-widget="fullscreen" href="#" role="button">
        <i class="fas fa-expand-arrows-alt"></i>
      </a>
    </li>
  </ul>
</nav>
<!-- /.navbar -->