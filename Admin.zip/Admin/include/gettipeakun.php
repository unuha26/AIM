<?php
$user = $_SESSION['usernameam'];
$data = mysqli_query($konek, "SELECT * FROM user WHERE Username = '$user'");
$getdata = mysqli_fetch_array($data);
$gettipeakun = $getdata['Tipe_Akun'];
$getid = $getdata['Id'];

$datak = mysqli_query($konek, "SELECT * FROM `kantor` where Id_User = '$getid'");
$getdatak = mysqli_fetch_array($datak);
$getkantor = $getdatak['Kantor'];
