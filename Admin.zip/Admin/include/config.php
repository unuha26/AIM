<?php


date_default_timezone_set("Asia/Jakarta");
setlocale(LC_ALL, 'id_ID');
$date = date("Y-m-d");
$time = date("h:i:s");

$host = "localhost";
$user = "root";
$pass = "";
$db = "aim";

$konek = mysqli_connect($host, $user, $pass, $db);
if (!$konek) {
    die("Error #1");
}
$specialaccess = 'rifkaa';
// $setadmin = "unuha26";

// error_reporting(E_ERROR);
