<?php
ini_set('session.gc_maxlifetime', 2678400);
ob_start();
session_start();
require_once("include/config.php");
require_once("include/gettipeakun.php");
// cek user login dengan session yg benar
if (!isset($_SESSION['usernameam']) or !isset($_SESSION['csam'])) {
  header("Location: login");
  die();
} else {
  $usernameam = $_SESSION['usernameam'];
  $sessionam = $_SESSION['csam'];
  $ceksession = mysqli_query($konek, "select * from user where username='$usernameam'");
  $xceksession = mysqli_fetch_array($ceksession);
  $truesession = $xceksession['session'];
  if ($_SESSION['csam'] <> $truesession) {
    header("Location: login");
    die();
  } else {
    // ini yang dipakai
    include("include/header.php");
    $xdata = mysqli_query($konek, "select * from user where Username='$usernameam'");
    $getdata = mysqli_fetch_array($xdata);
    $getnama = $getdata['Nama'];
    $fnadmin = explode(" ", $getnama);
    // pilihfpindah tambahfundraiser tambahmitra

    if (isset($_POST['pindahfundraiser'])) {
      $pilihfpindah = $_POST['pilihfpindah'];
      $tambahfundraiser = $_POST['tambahfundraiser'];
      $tambahmitra = $_POST['tambahmitra'];

      if (!$pilihfpindah  || !$tambahfundraiser) {
        $pesan = "<span>Lengkapi data dengan benar</span>";
      } else {
        $data = mysqli_query($konek, "SELECT * FROM fundraiser WHERE Nama = '$pilihfpindah'");
        $getdata = mysqli_fetch_array($data);
        $getnama = $getdata['Nama'];
        if ($getnama != '') {
          if ($tambahfundraiser == 'Publik') {
            $insert = mysqli_query($konek, "update fundraiser SET Status_Mitra = 'Publik', Mitra = '' WHERE Nama = '$pilihfpindah'");
          } else {
            $insert = mysqli_query($konek, "update fundraiser SET Status_Mitra = '$tambahfundraiser', Mitra = '$tambahmitra' WHERE Nama = '$pilihfpindah'");
          }
        } else {
          $data = mysqli_query($konek, "SELECT * FROM user WHERE Nama = '$pilihfpindah'");
          $getdata = mysqli_fetch_array($data);
          $getid = $getdata['Id'];
          $insert = mysqli_query($konek, "INSERT INTO `fundraiser` VALUES ('', '$pilihfpindah','$getid','$tambahfundraiser','$tambahmitra');");
        }
      }
    }

    if (isset($_POST['pindahdivisi'])) {
      $pilihsdmpindah = $_POST['pilihsdmpindah'];
      $divisipindah = $_POST['divisipindah'];
      $pilihkantorpindah = $_POST['pilihkantorpindah'];

      if (!$pilihsdmpindah  || !$divisipindah || !$pilihkantorpindah) {
        $pesan = "<span>Lengkapi data dengan benar</span>";
      } else {
        $data = mysqli_query($konek, "SELECT user.Id FROM user WHERE user.Nama = '$pilihsdmpindah'");
        $getdata = mysqli_fetch_array($data);
        $getid = $getdata['Id'];

        $insert = mysqli_query($konek, "UPDATE user SET `Tipe_Akun`='$divisipindah' WHERE `Nama`='$pilihsdmpindah'");
        $inser2 = mysqli_query($konek, "UPDATE kantor SET Kantor = '$pilihkantorpindah' WHERE Id_User = '$getid'");
        $pesan = "<span>Data berhasil disimpan</span>";
      }
    }

    if (isset($_POST['tambahakad'])) {
      $NamaAkadTambah = $_POST['NamaAkadTambah'];
      $KelompokDanaTambah = $_POST['KelompokDanaTambah'];
      $KelompokDanaBaruTambah = $_POST['KelompokDanaBaruTambah'];

      if (!$NamaAkadTambah) {
        $pesan = "<span>Lengkapi data dengan benar</span>";
      } else if (!$KelompokDanaTambah && !$KelompokDanaBaruTambah) {
        $pesan = "<span>Lengkapi data dengan benar</span>";
      } else if (!$KelompokDanaBaruTambah) {
        $insert = mysqli_query($konek, "INSERT INTO `akad` VALUES ('', '$KelompokDanaTambah','$NamaAkadTambah');");
        $pesan = "<span>Data berhasil disimpan</span>";
      } else if (!$KelompokDanaTambah) {
        $insert = mysqli_query($konek, "INSERT INTO `akad` VALUES ('', '$KelompokDanaBaruTambah','$NamaAkadTambah');");
        $pesan = "<span>Data berhasil disimpan</span>";
      }
    }

    if (isset($_POST['tambahmetode'])) {
      $tPenanggungJawab = $_POST['PenanggungJawabTambah'];
      $tNamaMetode = $_POST['NamaMetodeTambah'];

      if (!$tPenanggungJawab || !$tNamaMetode) {
        $pesan = "<span>Lengkapi data dengan benar</span>";
      } else {
        $insert = mysqli_query($konek, "INSERT INTO `metode` VALUES ('', '$tNamaMetode','$tPenanggungJawab');");
        $pesan = "<span>Data berhasil disimpan</span>";
      }
    }

    if (isset($_POST['tambahkantor'])) {
      $tnamakantor = $_POST['NamaKantorTambah'];
      $tcpkantor = $_POST['CpKantorTambah'];
      $talamatkantor = $_POST['AlamatKantorTambah'];

      if (!$tnamakantor || !$tcpkantor || !$talamatkantor) {
        $pesan = "<span>Lengkapi data dengan benar</span>";
      } else {
        $insert = mysqli_query($konek, "INSERT INTO `daftar_kantor` VALUES ('', '$tnamakantor','$tcpkantor','$talamatkantor');");
        $pesan = "<span>Data berhasil disimpan</span>";
      }
    }

    if (isset($_POST['submitdonasi']) || isset($_POST['submitdonasi2'])) {
      $dnohp = $_POST['donasinohp'];
      $dnama = $_POST['donasinama'];
      $dnominal = $_POST['donasinominal'];
      $dbank = $_POST['donasibank'];
      $dfundraiser = $_POST['donasifundraiser'];
      $dprogram = $_POST['donasiprogram'];
      $dketerangan = $_POST['donasiketerangan'];
      // $dthisname = $_POST['thisname'];
      $dthisnamel = $_POST['thisnamelist'];
      $dkategori =  $_POST['donasikategori'];
      $ddate =  $_POST['datedonasi'];
      // $sekarang = date("Y-m-d");
      $ceksekarang = date("Y-m-d");

      if ($ddate != '') {
        $sekarang = $ddate;
      } else {
        $sekarang = date("Y-m-d");
      }


      $getlastidd = mysqli_query($konek, "select Id from user_donatur ORDER BY Id DESC LIMIT 1");
      $lastidd = $getlastidd->fetch_object()->Id + 1;

      $getnohp = mysqli_query($konek, "select * from user_donatur where  `CP` ='$dnohp'");
      $datanohp = mysqli_fetch_array($getnohp);
      $thisnohp = $datanohp['CP'];

      if (
        !$dnohp || !$dnominal || !$dbank || !$dfundraiser || !$dprogram
      ) {
        $pesan = "<span>Lengkapi data dengan benar</span>";
      } else {
        if ($dnohp == $thisnohp && $dnama == '') {
          $getiddonatur = mysqli_query($konek, "select * from user_donatur where CP='$dnohp'");
          $thisgetiddonatur = mysqli_fetch_array($getiddonatur);
          $thisiddonatur = $thisgetiddonatur['Id'];

          $getfundraiser = mysqli_query($konek, "select Id_Fundaiser from donatur where Id_Fundaiser='$dfundraiser' and Id_Donatur= '$thisiddonatur';");
          $thisgetfundraiser = mysqli_fetch_array($getfundraiser);
          $thisiisfundraiser = $thisgetfundraiser['Id_Fundaiser'];

          if ($thisiisfundraiser == '') {
            $insert = mysqli_query($konek, "INSERT INTO `kas_masuk` VALUES ('', '$thisiddonatur', '$sekarang', '$dthisnamel', '$dprogram', '$dfundraiser', '$dbank', '$dnominal','$dketerangan', '$getnama');");
            $insert3 = mysqli_query($konek, "INSERT INTO `donatur` VALUES ('', '$thisiddonatur', '$dfundraiser');");
          } else {
            $insert = mysqli_query($konek, "INSERT INTO `kas_masuk` VALUES ('', '$thisiddonatur', '$sekarang', '$dthisnamel', '$dprogram', '$dfundraiser', '$dbank', '$dnominal','$dketerangan', '$getnama');");
            // $insert3 = mysqli_query($konek, "INSERT INTO `donatur` VALUES ('', '$thisiddonatur', '$dfundraiser');");
          }
        } else if ($dnohp == $thisnohp && $dnama != '') {
          $getiddonatur = mysqli_query($konek, "select * from user_donatur where CP='$dnohp'");
          $thisgetiddonatur = mysqli_fetch_array($getiddonatur);
          $thisiddonatur = $thisgetiddonatur['Id'];

          $getfundraiser = mysqli_query($konek, "select Id_Fundaiser from donatur where Id_Fundaiser='$dfundraiser' and Id_Donatur= '$thisiddonatur';");
          $thisgetfundraiser = mysqli_fetch_array($getfundraiser);
          $thisiisfundraiser = $thisgetfundraiser['Id_Fundaiser'];

          if ($thisiisfundraiser == '') {
            $insert = mysqli_query($konek, "INSERT INTO `kas_masuk` VALUES ('', '$thisiddonatur', '$sekarang', '$dnama', '$dprogram', '$dfundraiser', '$dbank', '$dnominal','$dketerangan', '$getnama');");
            $insert3 = mysqli_query($konek, "INSERT INTO `donatur` VALUES ('', '$thisiddonatur', '$dfundraiser');");
          } else {
            $insert = mysqli_query($konek, "INSERT INTO `kas_masuk` VALUES ('', '$thisiddonatur', '$sekarang', '$dnama', '$dprogram', '$dfundraiser', '$dbank', '$dnominal','$dketerangan', '$getnama');");
          }
        } else if ($dthisnamel != '' && $dnama != '') {
          $insert = mysqli_query($konek, "INSERT INTO `kas_masuk` VALUES ('', '$lastidd', '$sekarang', '$dthisnamel', '$dprogram', '$dfundraiser', '$dbank', '$dnominal','$dketerangan', '$getnama');");
          $insert2 = mysqli_query($konek, "INSERT INTO `user_donatur` VALUES ('$lastidd', '$dnama', '$dnohp', '$sekarang','$dkategori');");
          $insert3 = mysqli_query($konek, "INSERT INTO `donatur` VALUES ('', '$lastidd', '$dfundraiser');");
        } else {
          $insert = mysqli_query($konek, "INSERT INTO `kas_masuk` VALUES ('', '$lastidd', '$sekarang', '$dnama', '$dprogram', '$dfundraiser', '$dbank', '$dnominal','$dketerangan', '$getnama');");
          $insert2 = mysqli_query($konek, "INSERT INTO `user_donatur` VALUES ('$lastidd', '$dnama', '$dnohp', '$sekarang','$dkategori');");
          $insert3 = mysqli_query($konek, "INSERT INTO `donatur` VALUES ('', '$lastidd', '$dfundraiser');");
        }
      }
      if ($_POST['submitdonasi2'] = 1) {
        $getlastidd = mysqli_query($konek, "SELECT Id FROM `kas_masuk` ORDER BY `Id` DESC LIMIT 1");
        $lastidd = $getlastidd->fetch_object()->Id;
        echo "<script type=\"text/javascript\">
        window.open('nota?Id=" . $lastidd . "', '_blank')
    </script>";
      }
    }

    if (isset($_POST['submit'])) {
      $tusername = trim(stripslashes(strip_tags(htmlspecialchars(mysqli_real_escape_string($konek, $_POST['tambahusername'])))));
      $tpassword = trim(stripslashes(strip_tags(htmlspecialchars(mysqli_real_escape_string($konek, md5($_POST['tambahpassword']))))));

      $tnama = $_POST['tambahnama'];
      $tnohp = $_POST['tambahnohp'];
      $takun = $_POST['tambahtipeakun'];
      $tkantor = $_POST['tambahkantor'];
      $tfundraiser = $_POST['tambahfundraiser'];
      $tmitra = $_POST['tambahmitra'];
      $sekarang = date("Y-m-d");
      // $sekarang = date("Y-m-d H:i:s");

      $getlastid = mysqli_query($konek, "select Id from user ORDER BY Id DESC LIMIT 1");
      $lastid = $getlastid->fetch_object()->Id + 1;
      $setid = $getlastid->fetch_object()->Id;

      $get = mysqli_query($konek, "select * from user where Username='$tusername'");
      $data = mysqli_fetch_array($get);
      $username = $data['Username'];
      if (!$tusername || !$tpassword || !$tnama || !$tnohp || !$takun || !$tkantor) {
        $pesan = "<span>Lengkapi data dengan benar</span>";
      } else {
        // if ($username != $tusername)
        if ($username == $tusername) {
          $pesan = "<span>Username sudah di gunakan!</span>";
        } else if ($username != $tusername) {
          $insert = mysqli_query($konek, "INSERT INTO `user` VALUES ('$lastid', '$tnama', '$tnohp', '$tusername', '$tpassword', '$takun', '$sekarang', '', '$getnama');");
          if ($insert) {
            $insert2 = mysqli_query($konek, "INSERT INTO `kantor` VALUES ('', '$tkantor', '$lastid');");
            $pesan = "<span>Data berhasil di simpan</span>";
            if ($insert2) {
              if ($tfundraiser != '') {
                if ($tfundraiser == 'Fundraiser') {
                  $insert3 = mysqli_query($konek, "INSERT INTO `fundraiser` VALUES ('', '$tnama', '$lastid', '$tfundraiser', '');");
                } else if ($tfundraiser == 'Mitra') {
                  if ($tmitra != '') {
                    $insert4 = mysqli_query($konek, "INSERT INTO `fundraiser` VALUES ('', '$tnama', '$lastid', '$tfundraiser', '$tmitra');");
                  } else if ($tmitra == '') {
                    $pesan = "<span>Lengkapi data dengan benar</span>";
                  }
                }
              }
            }
          }
        }
      }
    }
?>


    <body class="hold-transition">
      <div class="wrapper">

        <?php
        include("include/menu.php");
        include("func/terbilang.php");
        ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
          <!-- Main content -->
          <div class="content" style="padding: 20px;">
            <div class="container-fluid">
              <div class="row">
                <div class="col-lg-6">
                  <?php
                  if ($gettipeakun == 'superuser' ||  $gettipeakun == 'Manager' ||  $gettipeakun == 'Admin') {
                    require_once("content/kasmasuk01.php");
                  } else header("location: view");
                  ?>
                  <!-- TAMBAH KANTOR -->
                  <?php
                  if ($gettipeakun == 'superuser' || $user == $specialaccess) {
                    require_once("content/tambahkantor02.php");
                  }
                  ?>
                  <!-- TAMBAH METODE PEMBAYARAN -->
                  <?php
                  if ($gettipeakun == 'superuser' ||  $gettipeakun == 'Manager' ||  $gettipeakun == 'Admin') {
                    require_once("content/tambahmtode03.php");
                  }
                  ?>
                  <!-- TAMBAH AKAD -->
                  <?php
                  if ($gettipeakun == 'superuser' ||  $gettipeakun == 'Manager' ||  $gettipeakun == 'Admin') {
                    require_once("content/tambahakad04.php");
                  }
                  ?>

                </div>
                <!-- /.col-md-6 -->
                <div class="col-lg-6">
                  <!-- TAMBAH USER -->
                  <?php
                  if ($gettipeakun == 'superuser' ||  $gettipeakun == 'Manager' ||  $gettipeakun == 'Admin') {
                    require_once("content/tambahuser05.php");
                  }
                  ?>
                  <!-- PINDAH DIVISI -->
                  <?php
                  if ($gettipeakun == 'superuser' ||  $gettipeakun == 'Manager' ||  $gettipeakun == 'Admin') {
                    require_once("content/pindahdivisi06.php");
                  }
                  ?>
                  <!-- UPDATE FUNDRAISER -->
                  <?php
                  if ($gettipeakun == 'superuser' ||  $gettipeakun == 'Manager' ||  $gettipeakun == 'Admin') {
                    require_once("content/updatefundraiser07.php");
                  }
                  ?>
                </div>
                <!-- /.col-md-6 -->
              </div>
              <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
          </div>
          <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->

        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
          <!-- Control sidebar content goes here -->
        </aside>
        <!-- /.control-sidebar -->
      </div>
      <!-- ./wrapper -->

      <script>
        $(function() {
          $("#DataTable1").DataTable({
            "responsive": true,
            "lengthChange": false,
            "autoWidth": false,
            "buttons": ["copy", "csv", "excel", "pdf", "print"]
          }).buttons().container().appendTo('#DataTable1_wrapper .col-md-6:eq(0)');
          $('#example1').DataTable({
            "paging": true,
            "lengthChange": false,
            "searching": false,
            "ordering": true,
            "info": true,
            "autoWidth": false,
            "responsive": true,
          });

        });


        function getdata_nama(type) {
          var cek = $("#donasinohp").val();
          $.ajax({
            url: 'func/cekname.php',
            data: 'donasinohp=' + cek,
            type: 'GET',
            dataType: 'html',
            success: function(msg) {
              $("#thisname").html(msg);
            }
          });

        }

        function getdata_namaf(type) {
          var cek = $("#thisnamelist").val();
          $.ajax({
            url: 'func/ceknamef.php',
            data: 'thisnamelist=' + cek,
            type: 'GET',
            dataType: 'html',
            success: function(msg) {
              $("#donasifundraiserlist").html(msg);
            }
          });

        }

        function getdata_idf(type) {
          var cek = $("#donasinanaslist").val();
          $.ajax({
            url: 'func/cekidf.php',
            data: 'donasinanaslist=' + cek,
            type: 'GET',
            dataType: 'html',
            success: function(msg) {
              $("#donasinohp2").html(msg);
            }
          });

        }
        // $(document).ready(function() {
        //   $("#searchbyname").click(function() {
        //     $("#donasinamashide").toggle();
        //   });
        // });
        // $(document).ready(function() {
        //   $("#donasinohp2").click(function() {
        //     var cek = $("#donasinohp2").val();
        //     $('#donasinohp').val(cek);
        //   });
        // });
      </script>

  <?php
  }
}
include("include/footer.php");
  ?>
    </body>

    </html>