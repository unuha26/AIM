<?php

require_once("../include/config.php");
$id = $_GET['donasinanaslist'];

if ($id != '') {

    $getname = mysqli_query($konek, "SELECT user_donatur.Id, user_donatur.CP, user_donatur.Nama_Donatur, fundraiser.Nama  FROM `donatur`
INNER JOIN fundraiser ON fundraiser.Id_User = donatur.Id_Fundaiser
INNER JOIN user_donatur ON user_donatur.Id = donatur.Id_Donatur
WHERE `Nama_Donatur` = '$id' order by Id");
    while ($thisname = mysqli_fetch_array($getname)) {
        echo '<option value="' . $thisname['CP'] . '">CP ' . $thisname['CP'] . ' - ' . $thisname['Nama_Donatur'] . ' - Exsisting ' . $thisname['Nama'] . '</option>';
    }
}
