<?php
$day = date('d');
// $day = 15;
// $day1 = $day - 1;
$month = date('m');
// $month = 3;
$month1 = $month - 1;
$years = date('Y');
$prevday = $years . '-' . $month . '-' . $day;
if ($years == 2021) {
    if ($day <= 25) {
        if ($month <= 1) {
            $prevmonth = 12;
            $thismonth = $month;
            $thisyears = $years;
            $prevyears = $years - 1;
        } else if ($month >= 12) {
            $prevmonth = $month - 1;
            $thismonth = $month;
            $thisyears = $years;
            $prevyears = $years;
        } else {
            $thismonth = $month + 1;
            $prevmonth = $month;
            $prevyears = $years;
            $thisyears = $years;
        }
    } else {
        if ($month <= 1) {
            $prevmonth = 1;
            $thismonth = $month + 1;
            $thisyears = $years;
            $prevyears = $years - 1;
        } else if ($month >= 12) {
            $prevmonth = 12;
            $thismonth = 1;
            $thisyears = $years + 1;
            $prevyears = $years;
        } else {
            $thismonth = $month + 1;
            $prevmonth = $month;
            $prevyears = $years;
            $thisyears = $years;
        }
    }

    $thismonth1 = $thismonth - 1;
    $prevmonth1 = $prevmonth - 1;
    $nextperiod = $thisyears . '-' . $thismonth . '-25';
    $prevperiod = $prevyears . '-' . $prevmonth . '-26';
    $prevperiodlalu = $prevyears . '-' . $thismonth1 . '-25';
    $nextperiodlalu = $thisyears . '-' . $prevmonth1 . '-26';
} else if ($years == 2022 and $month == 1) {
    if ($day <= 20) {
        $prevyears = $years - 1;
        $prevmonth = 12;
        $thismonth = $month;
        $thisyears = $years;
        $nextperiod = $thisyears . '-' . $thismonth . '-20';
        $prevperiod = $prevyears . '-' . $prevmonth . '-26';

        $thismonth1 = 11;
        $prevmonth1 = $prevmonth;
        $prevperiodlalu = '2021-' . $thismonth1 . '-25';
        $nextperiodlalu = '2021-' . $prevmonth1 . '-26';
    } else {
        if ($month <= 1) {
            $prevmonth = 1;
            $thismonth = $month + 1;
            $thisyears = $years;
            $prevyears = $years;
        }
        $nextperiod = $thisyears . '-' . $thismonth . '-20';
        $prevperiod = $prevyears . '-' . $prevmonth . '-21';
        $prevperiodlalu = '2021-12-26';
        $nextperiodlalu = '2022-01-20';
    }
} else {
    if ($day <= 20) {
        if ($month <= 1) {
            $prevmonth = 12;
            $thismonth = $month;
            $thisyears = $years;
            $prevyears = $years - 1;
            $prevmonth1 = 12;
        } else if ($month >= 12) {
            $prevmonth = $month - 1;
            $thismonth = $month;
            $thisyears = $years;
            $prevyears = $years;
        } else {
            $thismonth = $month;
            $prevmonth = $month - 1;
            $prevyears = $years;
            $thisyears = $years;
            $thismonth1 = $thismonth - 1;
            $prevmonth1 = $prevmonth - 1;
            $thisyears1 = $years;
            $prevyears1 = $years;
            if ($prevmonth1 == 0) {
                $thismonth1 = 1;
                $prevmonth1 = 12;
                $thisyears1 = $years;
                $prevyears1 = $years - 1;
            }
        }
    } else {
        if ($month <= 1) {
            $prevmonth = 1;
            $thismonth = $month + 1;
            $thisyears = $years;
            $prevyears = $years - 1;
            $prevyears1 = $years;
            $thisyears1 = $years;
        } else if ($month >= 12) {
            $prevmonth = 12;
            $thismonth = 1;
            $thisyears = $years + 1;
            $prevyears = $years;
            $prevyears1 = $years;
            $thisyears1 = $years;
        } else {
            $thismonth = $month + 1;
            $prevmonth = $month;
            $prevyears = $years;
            $thisyears = $years;
            $prevyears1 = $years;
            $thisyears1 = $years;
            $thismonth1 = $thismonth - 1;
            $prevmonth1 = $prevmonth - 1;
        }
    }
    $nextperiod = $thisyears . '-' . $thismonth . '-20';
    $prevperiod = $prevyears . '-' . $prevmonth . '-21';
    $nextperiodlalu = $thisyears1 . '-' . $thismonth1 . '-20';
    $prevperiodlalu = $prevyears1 . '-' . $prevmonth1 . '-21';
}
