<?php

require_once("../include/config.php");
require_once("../include/gettipeakun.php");
$id = $_GET['thisnamelist'];
// $cekn = $_GET['donasinama'];
// $cektn = $_GET['thisname'];
// $cektn2 = $_GET['thisname2'];

if ($id != '' && $id != 'Hamba Allah') {
    $getid = mysqli_query($konek, "SELECT * FROM user_donatur WHERE Nama_Donatur = '$id'");
    $dataid = mysqli_fetch_array($getid);
    $thisid = $dataid['Id'];

    $getname = mysqli_query($konek, "SELECT donatur.Id_Fundaiser, fundraiser.Nama FROM `donatur`
                                    INNER JOIN fundraiser ON fundraiser.Id_User = donatur.Id_Fundaiser
                                    WHERE `Id_Donatur` = '$thisid';");
    while ($thisname = mysqli_fetch_array($getname)) {
        echo '<option value="' . $thisname['Id_Fundaiser'] . '">' . $thisname['Nama'] . ' - Existing</option>';
    }
    // $getid2 = mysqli_query($konek, "SELECT donatur.Id_Fundaiser, fundraiser.Nama FROM `donatur`
    //                                 INNER JOIN fundraiser ON fundraiser.Id_User = donatur.Id_Fundaiser
    //                                 WHERE `Id_Donatur` = '$thisid';");
    // $dataid2 = mysqli_fetch_array($getid2);
    // $thisid2 = $dataid2['Id_Fundaiser'];
    $getname2 = mysqli_query($konek, "SELECT * FROM `fundraiser` ORDER BY Nama ASC;");
    while ($thisname2 = mysqli_fetch_array($getname2)) {
        echo '<option value="' . $thisname2['Id_User'] . '">' . $thisname2['Nama'] . '</option>';
    }
} else
    $getf = mysqli_query($konek, "SELECT * FROM fundraiser ORDER BY Nama ASC");
while ($rowf = mysqli_fetch_array($getf)) {
    echo '<option value="' . $rowf['Id_User'] . '">' . $rowf['Nama'] . '</option>';
}


// $getname = mysqli_query($konek, "SELECT * FROM user_donatur WHERE CP = '$id'");
// $thisname = mysqli_fetch_array($getname);

// if ($cekn != '' && $cektn == '') {
//     $show = '<input type="text" name="thisname2" id="thisname2" class="form-control">';
// }
