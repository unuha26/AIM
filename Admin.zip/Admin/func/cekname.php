<?php

require_once("../include/config.php");
$id = $_GET['donasinohp'];

if ($id != '') {

    $getname = mysqli_query($konek, "SELECT * FROM user_donatur WHERE CP LIKE '$id'");
    while ($thisname = mysqli_fetch_array($getname)) {
        echo '<option value="' . $thisname['Nama_Donatur'] . '"></option>';
    }
}
